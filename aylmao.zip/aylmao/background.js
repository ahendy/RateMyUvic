chrome.runtime.onMessage.addListener(function(request, sender, sendResponse){
	if ("professors" in request){
		console.log(JSON.stringify(request));
		localStorage["professors"] = JSON.stringify(request);
		console.log("msg recieved!");


	}else{


			try{
			     $.get(request.teach.url, function(data){
			                var $response = (data);
			                var test = {infos: $response, teachObj: request.teach, each: request.each};
			                sendResponse(test);

			        });
			    }catch(err){
			        console.log(err);

			    }


			return true;
	}
	
	
});






		
		