

var myArray = [
{
"firstname": "Jackson",
"lastname": "bears",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1786855"},
{
"firstname": "George",
"lastname": "Abbott",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1796445"},
{
"firstname": "Susan",
"lastname": "Russek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1276960"},
{
"firstname": "James",
"lastname": "Acken",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1675638"},
{
"firstname": "Martin",
"lastname": "Adam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=313561"},
{
"firstname": "Michael",
"lastname": "Adams",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=235814"},
{
"firstname": "Victoria",
"lastname": "Adamson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1112652"},
{
"firstname": "Charles",
"lastname": "Adeyanju",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=724235"},
{
"firstname": "Elizabeth",
"lastname": "Tettey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27915"},
{
"firstname": "Francis",
"lastname": "Febiri",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29960"},
{
"firstname": "Thomas",
"lastname": "Aechtner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1589662"},
{
"firstname": "Panajotis",
"lastname": "Agathoklis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=99878"},
{
"firstname": "Martial",
"lastname": "Agueh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=832887"},
{
"firstname": "Bijan",
"lastname": "Ahmadi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1698661"},
{
"firstname": "Jooeun",
"lastname": "Ahn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1979023"},
{
"firstname": "Pip",
"lastname": "Akins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250547"},
{
"firstname": "Justin",
"lastname": "Albert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1685021"},
{
"firstname": "Alexandra",
"lastname": "Albu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1275896"},
{
"firstname": "Robert",
"lastname": "Alexander",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=84817"},
{
"firstname": "Vikky",
"lastname": "Alexander",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=103990"},
{
"firstname": "Taiaiake",
"lastname": "Alfred",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76135"},
{
"firstname": "Mahsa",
"lastname": "Allahbakhshi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1156893"},
{
"firstname": "Diane",
"lastname": "Allan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1237903"},
{
"firstname": "James",
"lastname": "Allen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1694469"},
{
"firstname": "Kevin",
"lastname": "Allin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1000576"},
{
"firstname": "Catherine",
"lastname": "Althaus",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1237899"},
{
"firstname": "Seantel",
"lastname": "Anais",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1806625"},
{
"firstname": "Michaelangelo",
"lastname": "Anastasiou",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1909677"},
{
"firstname": "Andrew",
"lastname": "Andersen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30825"},
{
"firstname": "John",
"lastname": "Anderson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=128853"},
{
"firstname": "Starla",
"lastname": "Anderson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=923666"},
{
"firstname": "Don",
"lastname": "Anderson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1345811"},
{
"firstname": "Gregory",
"lastname": "Andrachuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=118220"},
{
"firstname": "Bradley",
"lastname": "Anholt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=34354"},
{
"firstname": "Dennis",
"lastname": "Anholt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=117518"},
{
"firstname": "Robert",
"lastname": "Anthony",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89812"},
{
"firstname": "Allan",
"lastname": "Antliff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=382784"},
{
"firstname": "Keith",
"lastname": "Anton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506088"},
{
"firstname": "John",
"lastname": "Antonioli",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1666033"},
{
"firstname": "Joseph",
"lastname": "Antos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1774573"},
{
"firstname": "Thomas",
"lastname": "Apple",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=226236"},
{
"firstname": "Janni",
"lastname": "Aragon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=817304"},
{
"firstname": "Angelika",
"lastname": "Arend",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55227"},
{
"firstname": "Deepali",
"lastname": "Arora",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1615159"},
{
"firstname": "Sibylle",
"lastname": "Artz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77302"},
{
"firstname": "Emily",
"lastname": "Arvay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1869893"},
{
"firstname": "Micheal",
"lastname": "Asch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1188158"},
{
"firstname": "David",
"lastname": "Atkinson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1566200"},
{
"firstname": "Janette",
"lastname": "Auer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=726949"},
{
"firstname": "Chris",
"lastname": "Auld",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1548362"},
{
"firstname": "Joshua",
"lastname": "Ault",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1659145"},
{
"firstname": "Juan",
"lastname": "Ausio",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92615"},
{
"firstname": "Chris",
"lastname": "Avery",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1163252"},
{
"firstname": "Kenneth",
"lastname": "Avio",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75222"},
{
"firstname": "Chris",
"lastname": "Avis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1267059"},
{
"firstname": "Ahmed",
"lastname": "Awad",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1113543"},
{
"firstname": "Guatam",
"lastname": "Awatramani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951693"},
{
"firstname": "Gautam",
"lastname": "Awatramani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951695"},
{
"firstname": "Eva",
"lastname": "Baboula",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=523196"},
{
"firstname": "Arif",
"lastname": "Babul",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=247308"},
{
"firstname": "Frances",
"lastname": "Backhouse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1945593"},
{
"firstname": "Joan",
"lastname": "Backus",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95542"},
{
"firstname": "Patricia",
"lastname": "Baer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=635887"},
{
"firstname": "Douglas",
"lastname": "Baer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89877"},
{
"firstname": "Jen",
"lastname": "Bagelman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1977896"},
{
"firstname": "Jen",
"lastname": "Baggs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=772788"},
{
"firstname": "Majid",
"lastname": "Bahrami",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=928646"},
{
"firstname": "Gerald",
"lastname": "Baillargeon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56633"},
{
"firstname": "Jody",
"lastname": "Bain",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54721"},
{
"firstname": "Teg",
"lastname": "Bains",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=256864"},
{
"firstname": "Ian",
"lastname": "Baird",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1425346"},
{
"firstname": "Richard",
"lastname": "Baker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1848011"},
{
"firstname": "Morgan",
"lastname": "Baker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38042"},
{
"firstname": "Herman",
"lastname": "Bakvis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=783105"},
{
"firstname": "Elizabeth",
"lastname": "Baldwin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76219"},
{
"firstname": "Walter",
"lastname": "Balfour",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=78143"},
{
"firstname": "Timothy",
"lastname": "Balzer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1583898"},
{
"firstname": "Natalie",
"lastname": "Ban",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1831303"},
{
"firstname": "Robert",
"lastname": "Bandringa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1458167"},
{
"firstname": "Sikata",
"lastname": "Banerjee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=17281"},
{
"firstname": "Amirali",
"lastname": "Baniasadi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=182635"},
{
"firstname": "Tracey",
"lastname": "Banks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1420425"},
{
"firstname": "Elena",
"lastname": "Baraban",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=96674"},
{
"firstname": "Brad",
"lastname": "Barclay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1024850"},
{
"firstname": "Adele",
"lastname": "Barclay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1873692"},
{
"firstname": "Stanley",
"lastname": "Bardal",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1384375"},
{
"firstname": "Gordon",
"lastname": "Barnes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=890501"},
{
"firstname": "Allison",
"lastname": "Barnes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1991731"},
{
"firstname": "Judith",
"lastname": "Barnes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1155180"},
{
"firstname": "Jeff",
"lastname": "Barnett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1029379"},
{
"firstname": "Chedo",
"lastname": "Barone",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=481066"},
{
"firstname": "Jes",
"lastname": "Bassi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1555130"},
{
"firstname": "Julia",
"lastname": "Baum",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1831576"},
{
"firstname": "Laurie",
"lastname": "Baxter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1072560"},
{
"firstname": "Sara",
"lastname": "Beam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52017"},
{
"firstname": "Doug",
"lastname": "Beardsley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65445"},
{
"firstname": "Angela",
"lastname": "Beattie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=458822"},
{
"firstname": "Hawley",
"lastname": "Beaugrand",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1175413"},
{
"firstname": "Gregory",
"lastname": "Beaulieu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=22999"},
{
"firstname": "Ilze",
"lastname": "Bebris",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=899846"},
{
"firstname": "Robert",
"lastname": "Bedeski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=87533"},
{
"firstname": "Rob",
"lastname": "Bedi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=884948"},
{
"firstname": "Julie",
"lastname": "Beeston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1177175"},
{
"firstname": "John",
"lastname": "Begoray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=783914"},
{
"firstname": "Noreen",
"lastname": "Begoray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38043"},
{
"firstname": "Susan",
"lastname": "Beiderwieden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=727099"},
{
"firstname": "Peter",
"lastname": "Bell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1912052"},
{
"firstname": "Alan",
"lastname": "Bell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=250797"},
{
"firstname": "Rick",
"lastname": "Bell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1035311"},
{
"firstname": "Stephen",
"lastname": "Benecke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1005264"},
{
"firstname": "Rainbow",
"lastname": "Bennett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95860"},
{
"firstname": "Colin",
"lastname": "Bennett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75221"},
{
"firstname": "Cecilia",
"lastname": "Benoit",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65301"},
{
"firstname": "Steve",
"lastname": "Benson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1463192"},
{
"firstname": "Dave",
"lastname": "Berg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1391711"},
{
"firstname": "Celina",
"lastname": "Berg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1750650"},
{
"firstname": "Benjamin",
"lastname": "Berger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=497503"},
{
"firstname": "Don",
"lastname": "Bergland",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1263172"},
{
"firstname": "Ed",
"lastname": "Berry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43482"},
{
"firstname": "Melissa",
"lastname": "Berry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1351135"},
{
"firstname": "Michael",
"lastname": "Best",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=86074"},
{
"firstname": "Maria",
"lastname": "Bettaglio",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1291328"},
{
"firstname": "Vinay",
"lastname": "Bharadia",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1149079"},
{
"firstname": "Ashoka",
"lastname": "Bhat",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=58730"},
{
"firstname": "Mohinder",
"lastname": "Bhatia",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1799595"},
{
"firstname": "Rustom",
"lastname": "Bhiladvala",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1776399"},
{
"firstname": "Perry",
"lastname": "Biddiscombe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30642"},
{
"firstname": "Ben",
"lastname": "Biffard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1468685"},
{
"firstname": "Jamie",
"lastname": "Biggar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1119994"},
{
"firstname": "Laura",
"lastname": "Biggs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1904559"},
{
"firstname": "Chris",
"lastname": "Bildfell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=762311"},
{
"firstname": "Eric",
"lastname": "Binion",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1331511"},
{
"firstname": "Robert",
"lastname": "Birch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1725995"},
{
"firstname": "Bob",
"lastname": "Bircher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=413624"},
{
"firstname": "Sonya",
"lastname": "Bird",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=425347"},
{
"firstname": "Daniel",
"lastname": "Biro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=473573"},
{
"firstname": "Kathie",
"lastname": "Black",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=522563"},
{
"firstname": "Ashley",
"lastname": "Blacquiere",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1953656"},
{
"firstname": "Natasha",
"lastname": "Cohen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=929917"},
{
"firstname": "Leslie",
"lastname": "Bland",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89863"},
{
"firstname": "Kim",
"lastname": "Blank",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27353"},
{
"firstname": "Gregory",
"lastname": "Blue",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39250"},
{
"firstname": "Adrian",
"lastname": "Blunt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1237898"},
{
"firstname": "Jessica",
"lastname": "Blythe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1656188"},
{
"firstname": "David",
"lastname": "Boag",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=82500"},
{
"firstname": "Christian",
"lastname": "Bock",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669196"},
{
"firstname": "Michael",
"lastname": "Bodden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=566151"},
{
"firstname": "Ken",
"lastname": "Bodnarchuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=833480"},
{
"firstname": "John",
"lastname": "Boehme",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=529738"},
{
"firstname": "Tim",
"lastname": "Bogle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1559967"},
{
"firstname": "Cornelia",
"lastname": "Bohne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=149013"},
{
"firstname": "B",
"lastname": "Bolaria",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=224122"},
{
"firstname": "Benjamin",
"lastname": "Bolden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1351600"},
{
"firstname": "Tolga",
"lastname": "Bolukbasi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1017058"},
{
"firstname": "Anita",
"lastname": "Bonkowski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=846330"},
{
"firstname": "Michelle",
"lastname": "Bonner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=379521"},
{
"firstname": "Michael",
"lastname": "Booth",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1616961"},
{
"firstname": "Alisdair",
"lastname": "Boraston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=614544"},
{
"firstname": "Jens",
"lastname": "Bornemann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1921274"},
{
"firstname": "John",
"lastname": "Borrows",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=33123"},
{
"firstname": "Elizaberth",
"lastname": "Borycki",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=973277"},
{
"firstname": "Chris",
"lastname": "Bose",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=48181"},
{
"firstname": "Andre",
"lastname": "Botha",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1385775"},
{
"firstname": "Heather",
"lastname": "Botting",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42654"},
{
"firstname": "Martin",
"lastname": "Boulanger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1038012"},
{
"firstname": "Enrico",
"lastname": "Bovero",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1332007"},
{
"firstname": "Laurel",
"lastname": "Bowman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=224678"},
{
"firstname": "Adrienne",
"lastname": "Boyarin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=999609"},
{
"firstname": "Shamma",
"lastname": "Boyarin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1092569"},
{
"firstname": "Melissa",
"lastname": "Boyce",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=854348"},
{
"firstname": "Peter",
"lastname": "Boychuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1698254"},
{
"firstname": "Chris",
"lastname": "Boyer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1127630"},
{
"firstname": "Wanda",
"lastname": "Boyer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=64056"},
{
"firstname": "Patrick",
"lastname": "Boyle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1750888"},
{
"firstname": "Kristina",
"lastname": "Brache",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1596320"},
{
"firstname": "Nicholas",
"lastname": "Bradley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1063180"},
{
"firstname": "Colin",
"lastname": "Bradley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1729296"},
{
"firstname": "Maureen",
"lastname": "Bradley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=530574"},
{
"firstname": "Michelle",
"lastname": "Brady",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1645871"},
{
"firstname": "Paul",
"lastname": "Brady",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11880"},
{
"firstname": "Paul",
"lastname": "Bramadat",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1589666"},
{
"firstname": "Mona",
"lastname": "Brash",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=773009"},
{
"firstname": "Gerhard",
"lastname": "Brauer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76599"},
{
"firstname": "Alan",
"lastname": "Breakspear",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1188477"},
{
"firstname": "Frederic",
"lastname": "Bremaud",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91395"},
{
"firstname": "Andreas",
"lastname": "Breuer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1920366"},
{
"firstname": "Douglas",
"lastname": "Briant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1230234"},
{
"firstname": "Mark",
"lastname": "Bridge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=71501"},
{
"firstname": "Alexander",
"lastname": "Briggs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1133582"},
{
"firstname": "Sandy",
"lastname": "Briggs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=17634"},
{
"firstname": "Elizabeth",
"lastname": "Brimacombe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54949"},
{
"firstname": "Alexandre",
"lastname": "Brolo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=94247"},
{
"firstname": "Caleb",
"lastname": "Bromba",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1259008"},
{
"firstname": "Jim",
"lastname": "Brookes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1630585"},
{
"firstname": "Jean",
"lastname": "Brouard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250643"},
{
"firstname": "Rhodes",
"lastname": "Brown",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=322694"},
{
"firstname": "Cindy",
"lastname": "Brown",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95377"},
{
"firstname": "Karen",
"lastname": "Brown",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=697734"},
{
"firstname": "Lucinda",
"lastname": "Brown",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1478457"},
{
"firstname": "Kim",
"lastname": "Brown",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1623601"},
{
"firstname": "Murray",
"lastname": "Browne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1189110"},
{
"firstname": "Jane",
"lastname": "Browning",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1239965"},
{
"firstname": "Bill",
"lastname": "Brownlee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1036986"},
{
"firstname": "Anne",
"lastname": "Bruce",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=958804"},
{
"firstname": "Emmanuel",
"lastname": "Jailly",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1750716"},
{
"firstname": "Conrad",
"lastname": "Brunk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1148514"},
{
"firstname": "Brad",
"lastname": "Bryan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=271971"},
{
"firstname": "Daniel",
"lastname": "Bryant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=124291"},
{
"firstname": "Penny",
"lastname": "Bryden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=772084"},
{
"firstname": "Daniel",
"lastname": "Bub",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45358"},
{
"firstname": "Brad",
"lastname": "Buckham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57135"},
{
"firstname": "J",
"lastname": "Buckley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39521"},
{
"firstname": "Bill",
"lastname": "Buckwold",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40125"},
{
"firstname": "Ryan",
"lastname": "Budney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1332057"},
{
"firstname": "Ian",
"lastname": "Bull",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=838420"},
{
"firstname": "Bette",
"lastname": "Bultena",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=111185"},
{
"firstname": "Martin",
"lastname": "Bunton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38120"},
{
"firstname": "Neil",
"lastname": "Burford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1597302"},
{
"firstname": "Sheila",
"lastname": "Burgar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=60622"},
{
"firstname": "Robert",
"lastname": "Burke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=334740"},
{
"firstname": "Brendan",
"lastname": "Burke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=331040"},
{
"firstname": "J",
"lastname": "Burke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=72855"},
{
"firstname": "Neil",
"lastname": "Burton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=504448"},
{
"firstname": "Ellen",
"lastname": "Busby",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=457703"},
{
"firstname": "Jacqueline",
"lastname": "Bush",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1832838"},
{
"firstname": "Kate",
"lastname": "Butler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1455806"},
{
"firstname": "Carolyn",
"lastname": "Palmer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1286323"},
{
"firstname": "Leslie",
"lastname": "Butt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35749"},
{
"firstname": "Jane",
"lastname": "Butterfield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1988547"},
{
"firstname": "Christopher",
"lastname": "Butterfield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=194649"},
{
"firstname": "Benjamin",
"lastname": "Butterfield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1015031"},
{
"firstname": "Sarah",
"lastname": "Buydens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1474840"},
{
"firstname": "Shawn",
"lastname": "Cafferky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=74483"},
{
"firstname": "Lin",
"lastname": "Cai",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=971111"},
{
"firstname": "Stephanie",
"lastname": "Calce",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1833651"},
{
"firstname": "Gillian",
"lastname": "Calder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=548520"},
{
"firstname": "Todd",
"lastname": "Calder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=458078"},
{
"firstname": "Judy",
"lastname": "Caldwell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29764"},
{
"firstname": "Cara",
"lastname": "Camcastle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=219342"},
{
"firstname": "Caroline",
"lastname": "Cameron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1334732"},
{
"firstname": "Ian",
"lastname": "Cameron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28649"},
{
"firstname": "Margaret",
"lastname": "Cameron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1232343"},
{
"firstname": "Erin",
"lastname": "Campbell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=209317"},
{
"firstname": "Micaela",
"lastname": "Campbell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=710735"},
{
"firstname": "Rosaline",
"lastname": "Canessa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=334344"},
{
"firstname": "Dante",
"lastname": "Canil",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=94147"},
{
"firstname": "Steven",
"lastname": "Capaldo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=467343"},
{
"firstname": "Don",
"lastname": "Caplan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1071831"},
{
"firstname": "Claire",
"lastname": "Carlin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=97996"},
{
"firstname": "Colleen",
"lastname": "Carpenter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=102944"},
{
"firstname": "Jeannine",
"lastname": "Carriere",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1109327"},
{
"firstname": "M",
"lastname": "Carroll",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=864015"},
{
"firstname": "Willian",
"lastname": "Carroll",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28161"},
{
"firstname": "Simon",
"lastname": "Carroll",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1837672"},
{
"firstname": "Luke",
"lastname": "Carson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37970"},
{
"firstname": "Constance",
"lastname": "Carter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1457980"},
{
"firstname": "Hugh",
"lastname": "Cartwright",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1676553"},
{
"firstname": "Jamie",
"lastname": "Cassels",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1807929"},
{
"firstname": "Heather",
"lastname": "Castleden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1131140"},
{
"firstname": "Annye",
"lastname": "Castonguay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=764390"},
{
"firstname": "M",
"lastname": "Cattral",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1013672"},
{
"firstname": "Natasha",
"lastname": "Caverley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1989597"},
{
"firstname": "Catherine",
"lastname": "Caws",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89556"},
{
"firstname": "Helene",
"lastname": "Cazes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54879"},
{
"firstname": "John",
"lastname": "Celona",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1109135"},
{
"firstname": "Kerem",
"lastname": "Cetinal",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1232230"},
{
"firstname": "Maxym",
"lastname": "Chaban",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=119167"},
{
"firstname": "Becky",
"lastname": "Chak",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43800"},
{
"firstname": "Lisa",
"lastname": "Chalykoff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=220297"},
{
"firstname": "Janette",
"lastname": "Champagne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1289519"},
{
"firstname": "Shelly",
"lastname": "Chan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1442410"},
{
"firstname": "Elsie",
"lastname": "Chan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=610056"},
{
"firstname": "Jothir",
"lastname": "Chandi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1416123"},
{
"firstname": "Melanie",
"lastname": "Chang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1797674"},
{
"firstname": "Ellen",
"lastname": "Chapco",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1033034"},
{
"firstname": "Jed",
"lastname": "Chapin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=249174"},
{
"firstname": "Alison",
"lastname": "Chapman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=764849"},
{
"firstname": "Neena",
"lastname": "Chappell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=817202"},
{
"firstname": "Moshi",
"lastname": "Charnell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75511"},
{
"firstname": "Vanessa",
"lastname": "Charvin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1888034"},
{
"firstname": "Joseph",
"lastname": "Chen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=405625"},
{
"firstname": "Weichun",
"lastname": "Chen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=712990"},
{
"firstname": "Zhongping",
"lastname": "Chen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91298"},
{
"firstname": "Angel",
"lastname": "Chen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1456520"},
{
"firstname": "Mantis",
"lastname": "Cheng",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=51132"},
{
"firstname": "Louise",
"lastname": "Chim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1875610"},
{
"firstname": "Thomas",
"lastname": "Chisholm",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1680884"},
{
"firstname": "Byoung",
"lastname": "Choi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=165164"},
{
"firstname": "Robert",
"lastname": "Chow",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1118784"},
{
"firstname": "Cary",
"lastname": "Chow",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=662452"},
{
"firstname": "Maria",
"lastname": "Chowdhury",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1327642"},
{
"firstname": "Francis",
"lastname": "Choy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=23252"},
{
"firstname": "Alex",
"lastname": "Christie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1965255"},
{
"firstname": "Juliette",
"lastname": "Christie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92429"},
{
"firstname": "Ken",
"lastname": "Chung",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=298926"},
{
"firstname": "Derek",
"lastname": "Church",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=10602"},
{
"firstname": "Wendell",
"lastname": "Clanton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=239902"},
{
"firstname": "Vanessa",
"lastname": "Clark",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1952667"},
{
"firstname": "Patricia",
"lastname": "Clark",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42657"},
{
"firstname": "Ti",
"lastname": "Clark",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=862066"},
{
"firstname": "Judith",
"lastname": "Clarke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91601"},
{
"firstname": "Santosh",
"lastname": "Clarke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1428624"},
{
"firstname": "Marlea",
"lastname": "Clarke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1484194"},
{
"firstname": "Jenny",
"lastname": "Clayton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1242192"},
{
"firstname": "Jevne",
"lastname": "Clayton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1724128"},
{
"firstname": "Tom",
"lastname": "Cleary",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43483"},
{
"firstname": "David",
"lastname": "Clenman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=319348"},
{
"firstname": "Rachel",
"lastname": "Cleves",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=713394"},
{
"firstname": "Denise",
"lastname": "Fisher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=333821"},
{
"firstname": "Yvonne",
"lastname": "Coady",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330726"},
{
"firstname": "Evelyn",
"lastname": "Cobley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91669"},
{
"firstname": "Ernest",
"lastname": "Cockayne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77632"},
{
"firstname": "Geoffrey",
"lastname": "Cocke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1076796"},
{
"firstname": "Penny",
"lastname": "Codding",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=69405"},
{
"firstname": "Silvia",
"lastname": "Cardona",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40495"},
{
"firstname": "Jason",
"lastname": "Colby",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1032794"},
{
"firstname": "Mark",
"lastname": "Colgate",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=101476"},
{
"firstname": "David",
"lastname": "Collins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1976859"},
{
"firstname": "Laurel",
"lastname": "Collins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1955561"},
{
"firstname": "Adam",
"lastname": "Con",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1988907"},
{
"firstname": "Greg",
"lastname": "Conner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1964239"},
{
"firstname": "C",
"lastname": "Constabel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=634836"},
{
"firstname": "Daniela",
"lastname": "Constantinescu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1031048"},
{
"firstname": "Laurence",
"lastname": "Coogan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1110002"},
{
"firstname": "Peter",
"lastname": "Cook",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506087"},
{
"firstname": "Peter",
"lastname": "Cook",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506085"},
{
"firstname": "Ryan",
"lastname": "Cook",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506086"},
{
"firstname": "Jason",
"lastname": "Corless",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55225"},
{
"firstname": "Jeff",
"lastname": "Corntassel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1978084"},
{
"firstname": "Vivien",
"lastname": "Corwin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1112512"},
{
"firstname": "Becky",
"lastname": "Cory",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1808021"},
{
"firstname": "Maycira",
"lastname": "Costa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=258902"},
{
"firstname": "Catherine",
"lastname": "Costigan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=50399"},
{
"firstname": "Karen",
"lastname": "Courtney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1698178"},
{
"firstname": "Pascal",
"lastname": "Courty",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1502281"},
{
"firstname": "Harold",
"lastname": "Coward",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=349396"},
{
"firstname": "Laura",
"lastname": "Cowen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=180653"},
{
"firstname": "Tim",
"lastname": "Craig",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=544861"},
{
"firstname": "Scott",
"lastname": "Craig",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=645488"},
{
"firstname": "Cheryl",
"lastname": "Crane",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=280454"},
{
"firstname": "Dede",
"lastname": "gaston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1679190"},
{
"firstname": "Curran",
"lastname": "Crawford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1007485"},
{
"firstname": "David",
"lastname": "Creasey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=17636"},
{
"firstname": "Jason",
"lastname": "Cressey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=797385"},
{
"firstname": "Stephen",
"lastname": "Cross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1381680"},
{
"firstname": "Lorna",
"lastname": "Crozier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=335033"},
{
"firstname": "Nadine",
"lastname": "Cruikshanks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=319602"},
{
"firstname": "Ross",
"lastname": "Crumrine",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=69744"},
{
"firstname": "Ajony",
"lastname": "Csaba",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1957590"},
{
"firstname": "Jay",
"lastname": "Cullen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=734652"},
{
"firstname": "Michael",
"lastname": "Cullen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39500"},
{
"firstname": "Bart",
"lastname": "Cunningham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=639569"},
{
"firstname": "Mary",
"lastname": "Cunningham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1924150"},
{
"firstname": "Claire",
"lastname": "Cupples",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=425426"},
{
"firstname": "Deborah",
"lastname": "Curran",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=964029"},
{
"firstname": "Brad",
"lastname": "Curry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=883292"},
{
"firstname": "Kathryn",
"lastname": "Curtis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75602"},
{
"firstname": "Nancy",
"lastname": "Cuthbert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1148742"},
{
"firstname": "A",
"lastname": "Cutler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89686"},
{
"firstname": "Monika",
"lastname": "Cwiartka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1715841"},
{
"firstname": "Ewa",
"lastname": "Higgins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89628"},
{
"firstname": "Alexandra",
"lastname": "Arcy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1658040"},
{
"firstname": "Valerie",
"lastname": "Erman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1613177"},
{
"firstname": "Leora",
"lastname": "Dahl",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=621651"},
{
"firstname": "Lucy",
"lastname": "Daigle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54880"},
{
"firstname": "Bob",
"lastname": "Dalton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=302380"},
{
"firstname": "Lorraine",
"lastname": "Dame",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=363798"},
{
"firstname": "Daniela",
"lastname": "Damian",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93369"},
{
"firstname": "Assem",
"lastname": "Dandashly",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1479815"},
{
"firstname": "Thomas",
"lastname": "Darcie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=486284"},
{
"firstname": "Heidi",
"lastname": "Darroch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1063426"},
{
"firstname": "Ali",
"lastname": "Dastmalchian",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=548777"},
{
"firstname": "Monique",
"lastname": "Davidson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1557154"},
{
"firstname": "Thomas",
"lastname": "Davis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=959344"},
{
"firstname": "Josiah",
"lastname": "Davis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1385534"},
{
"firstname": "Lyn",
"lastname": "Davis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1054006"},
{
"firstname": "JC",
"lastname": "Dawson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1003329"},
{
"firstname": "Teresa",
"lastname": "Dawson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1976426"},
{
"firstname": "Brian",
"lastname": "Day",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=244943"},
{
"firstname": "Beatriz",
"lastname": "Koch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=794473"},
{
"firstname": "Johan",
"lastname": "Boer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107919"},
{
"firstname": "Michele",
"lastname": "De La Chevrotiere",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1842588"},
{
"firstname": "Emile",
"lastname": "Rosany",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1386654"},
{
"firstname": "Rogerio",
"lastname": "Sousa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1075918"},
{
"firstname": "Misao",
"lastname": "Dean",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55072"},
{
"firstname": "Deanna",
"lastname": "Rivers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1959969"},
{
"firstname": "Philip",
"lastname": "Dearden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30727"},
{
"firstname": "Nikolai",
"lastname": "Dechev",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=942879"},
{
"firstname": "Maneesh",
"lastname": "Deckha",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=377511"},
{
"firstname": "Sandrina",
"lastname": "Definney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=584580"},
{
"firstname": "David",
"lastname": "Delafenetre",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1380156"},
{
"firstname": "Kerry",
"lastname": "Delaney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=738421"},
{
"firstname": "Senada",
"lastname": "Delic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1962036"},
{
"firstname": "Hulya",
"lastname": "Demirdirek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=465955"},
{
"firstname": "Jessica",
"lastname": "Dempsey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1773538"},
{
"firstname": "Yolina",
"lastname": "Denchev",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43595"},
{
"firstname": "Deborah",
"lastname": "Dergousoff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1336705"},
{
"firstname": "Celeste",
"lastname": "Derksen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45819"},
{
"firstname": "Craig",
"lastname": "Derksen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1625349"},
{
"firstname": "Radhika",
"lastname": "Desai",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=41030"},
{
"firstname": "Simon",
"lastname": "Devereaux",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=526751"},
{
"firstname": "Richard",
"lastname": "Dewey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=22997"},
{
"firstname": "Jason",
"lastname": "Dewinetz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=497365"},
{
"firstname": "Joyce",
"lastname": "Oosten",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=974661"},
{
"firstname": "Mandeep",
"lastname": "Dhami",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38079"},
{
"firstname": "Rita",
"lastname": "Dhamoon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1884858"},
{
"firstname": "Florin",
"lastname": "Diacu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89163"},
{
"firstname": "Rob",
"lastname": "Diaz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=632439"},
{
"firstname": "Yonas",
"lastname": "Dibike",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1198374"},
{
"firstname": "Megan",
"lastname": "Dickie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=927828"},
{
"firstname": "Katia",
"lastname": "Dilkina",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1420654"},
{
"firstname": "Jocelyn",
"lastname": "Dimm",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=171581"},
{
"firstname": "Nikitas",
"lastname": "Dimopoulos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37403"},
{
"firstname": "Brian",
"lastname": "Dippie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45595"},
{
"firstname": "Warwick",
"lastname": "Dobson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=934239"},
{
"firstname": "David",
"lastname": "Docherty",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38911"},
{
"firstname": "John",
"lastname": "Dolan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=940568"},
{
"firstname": "Holly",
"lastname": "Dolan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70006"},
{
"firstname": "Dave",
"lastname": "Dolff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=724230"},
{
"firstname": "Leland",
"lastname": "Donald",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=81302"},
{
"firstname": "Ranald",
"lastname": "Donaldson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89309"},
{
"firstname": "Xiaodai",
"lastname": "Dong",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=733625"},
{
"firstname": "Sandra",
"lastname": "Doore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1753869"},
{
"firstname": "Jamie",
"lastname": "Dopp",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43796"},
{
"firstname": "Stan",
"lastname": "Dosso",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=128619"},
{
"firstname": "Sadik",
"lastname": "Dost",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1388618"},
{
"firstname": "Christopher",
"lastname": "Douglas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=524306"},
{
"firstname": "Bethany",
"lastname": "Dowell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1598502"},
{
"firstname": "John",
"lastname": "Dower",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=108376"},
{
"firstname": "Eugene",
"lastname": "Dowling",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=116232"},
{
"firstname": "Angela",
"lastname": "Downey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1274025"},
{
"firstname": "Melissa",
"lastname": "Doyle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1261274"},
{
"firstname": "Susan",
"lastname": "Doyle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=48523"},
{
"firstname": "Anna",
"lastname": "Drake",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1680429"},
{
"firstname": "Peter",
"lastname": "Driessen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37404"},
{
"firstname": "Dennis",
"lastname": "Dubord",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=356814"},
{
"firstname": "Phil",
"lastname": "Duchene",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1585163"},
{
"firstname": "John",
"lastname": "Duder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37983"},
{
"firstname": "Karen",
"lastname": "Duder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=233575"},
{
"firstname": "Dennine",
"lastname": "Dudley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76547"},
{
"firstname": "Dave",
"lastname": "Duffus",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30818"},
{
"firstname": "Christopher",
"lastname": "Duffy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1600602"},
{
"firstname": "Anthony",
"lastname": "Dugbartey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=331402"},
{
"firstname": "Peter",
"lastname": "Dukes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=573855"},
{
"firstname": "Ivan",
"lastname": "Dumka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1831867"},
{
"firstname": "Laura",
"lastname": "Duncanson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1123994"},
{
"firstname": "Alexander",
"lastname": "Dunn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=233645"},
{
"firstname": "David",
"lastname": "Dunnet",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=62098"},
{
"firstname": "Bruno",
"lastname": "Dupeyron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=872055"},
{
"firstname": "John",
"lastname": "Durkin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=181433"},
{
"firstname": "Lheisa",
"lastname": "Dustin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1502065"},
{
"firstname": "Laura",
"lastname": "Dutton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1673010"},
{
"firstname": "Robin",
"lastname": "Dyke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1422698"},
{
"firstname": "Mark",
"lastname": "Ebert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=874853"},
{
"firstname": "Yousef",
"lastname": "Ebrahim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70987"},
{
"firstname": "Colleen",
"lastname": "Eccleston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=191035"},
{
"firstname": "Michael",
"lastname": "Edgell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38163"},
{
"firstname": "Anthony",
"lastname": "Edwards",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=59349"},
{
"firstname": "Roderick",
"lastname": "Edwards",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28543"},
{
"firstname": "Michelle",
"lastname": "Edwards",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=844434"},
{
"firstname": "Serena",
"lastname": "Edwardson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=895432"},
{
"firstname": "Barbara",
"lastname": "Ehlting",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1150065"},
{
"firstname": "Jeurgen",
"lastname": "Ehlting",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1639172"},
{
"firstname": "Caley",
"lastname": "Ehnes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1597510"},
{
"firstname": "Andrea",
"lastname": "Eidinger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1507439"},
{
"firstname": "Avigail",
"lastname": "Eisenberg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54573"},
{
"firstname": "Haytham",
"lastname": "Miligi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1752806"},
{
"firstname": "Watheq",
"lastname": "Kharashi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36621"},
{
"firstname": "A",
"lastname": "Elangovan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54596"},
{
"firstname": "Susan",
"lastname": "Elderkin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57642"},
{
"firstname": "Erin",
"lastname": "Ellerbeck",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1388766"},
{
"firstname": "Janice",
"lastname": "Elliot",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=382783"},
{
"firstname": "John",
"lastname": "Ellis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27465"},
{
"firstname": "Sara",
"lastname": "Ellison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=384621"},
{
"firstname": "Heath",
"lastname": "Emerson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=635421"},
{
"firstname": "Katsuhiko",
"lastname": "Endo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=946704"},
{
"firstname": "Merwan",
"lastname": "Engineer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=113284"},
{
"firstname": "Dennis",
"lastname": "Epple",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1366623"},
{
"firstname": "John",
"lastname": "Esling",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89080"},
{
"firstname": "Anthony",
"lastname": "Estey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1646646"},
{
"firstname": "Catherine",
"lastname": "Etmanski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1302375"},
{
"firstname": "Stephen",
"lastname": "Evans",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=741441"},
{
"firstname": "Corrina",
"lastname": "Ewan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1736239"},
{
"firstname": "Shannon",
"lastname": "Fargey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1960694"},
{
"firstname": "Carson",
"lastname": "Farmer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=957451"},
{
"firstname": "Martin",
"lastname": "Farnham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=457726"},
{
"firstname": "Charles",
"lastname": "Fedorak",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91179"},
{
"firstname": "Dennis",
"lastname": "Fedoruk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506089"},
{
"firstname": "Donna",
"lastname": "Feir",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1861722"},
{
"firstname": "Hui",
"lastname": "Feng",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=407757"},
{
"firstname": "Mary",
"lastname": "Fenimore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37984"},
{
"firstname": "Norm",
"lastname": "Fennema",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=349128"},
{
"firstname": "Stephen",
"lastname": "Ferance",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1877559"},
{
"firstname": "Donald",
"lastname": "Ferguson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89509"},
{
"firstname": "Gerry",
"lastname": "Ferguson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=212856"},
{
"firstname": "Michael",
"lastname": "Fern",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=792779"},
{
"firstname": "Candace",
"lastname": "Fertile",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=61999"},
{
"firstname": "Donald",
"lastname": "Fetherston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1652667"},
{
"firstname": "Stephen",
"lastname": "Fielding",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1862271"},
{
"firstname": "Michelle",
"lastname": "Fillion",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89054"},
{
"firstname": "Stephen",
"lastname": "Finbow",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=276433"},
{
"firstname": "Pasquale",
"lastname": "Fiore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1815159"},
{
"firstname": "Flavio",
"lastname": "Firmani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1909971"},
{
"firstname": "Jason",
"lastname": "Fisher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1419316"},
{
"firstname": "Laurie",
"lastname": "Fitzgerald",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1086186"},
{
"firstname": "Scott",
"lastname": "Fitzsimmons",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1386644"},
{
"firstname": "Mark",
"lastname": "Flaherty",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92044"},
{
"firstname": "Donna",
"lastname": "Fleming",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1291331"},
{
"firstname": "Diane",
"lastname": "Flood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1608989"},
{
"firstname": "Robert",
"lastname": "Florida",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1266041"},
{
"firstname": "Garret",
"lastname": "Flowers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1450724"},
{
"firstname": "Christine",
"lastname": "Forster",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40144"},
{
"firstname": "Jeffrey",
"lastname": "Foss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52007"},
{
"firstname": "Harold",
"lastname": "Foster",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93736"},
{
"firstname": "Hamar",
"lastname": "Foster",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=31649"},
{
"firstname": "John",
"lastname": "Fowler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1031929"},
{
"firstname": "Eric",
"lastname": "Foxall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1781757"},
{
"firstname": "Honore",
"lastname": "France",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56948"},
{
"firstname": "Yasuko",
"lastname": "France",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35752"},
{
"firstname": "Michael",
"lastname": "Francis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1885691"},
{
"firstname": "Leslie",
"lastname": "Pelton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=160038"},
{
"firstname": "Natia",
"lastname": "Frank",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=917198"},
{
"firstname": "Milan",
"lastname": "Frankl",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=689539"},
{
"firstname": "Kara",
"lastname": "Freeman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=896880"},
{
"firstname": "Laurie",
"lastname": "Freeman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1828925"},
{
"firstname": "Hugh",
"lastname": "French",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250636"},
{
"firstname": "Daniel",
"lastname": "Fridman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1464650"},
{
"firstname": "Sandra",
"lastname": "Friesen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1780066"},
{
"firstname": "Ingrid",
"lastname": "Friesen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=125504"},
{
"firstname": "Patrick",
"lastname": "Friesen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1348828"},
{
"firstname": "Emile",
"lastname": "Rosnay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1150158"},
{
"firstname": "Ange",
"lastname": "Frymire",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=855124"},
{
"firstname": "Judy",
"lastname": "Fudge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1040966"},
{
"firstname": "Gordon",
"lastname": "Fulton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55073"},
{
"firstname": "Laura",
"lastname": "Funk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=284344"},
{
"firstname": "Carla",
"lastname": "Hesketh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1149811"},
{
"firstname": "Thomas",
"lastname": "Fyles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1842658"},
{
"firstname": "Rebecca",
"lastname": "Gagan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=519312"},
{
"firstname": "Lynda",
"lastname": "Gagne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1541901"},
{
"firstname": "Chris",
"lastname": "Gainor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1144690"},
{
"firstname": "Carmen",
"lastname": "Galang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=125877"},
{
"firstname": "Nick",
"lastname": "Galichenko",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=47054"},
{
"firstname": "Glenn",
"lastname": "Gallins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=800662"},
{
"firstname": "Donald",
"lastname": "Galloway",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=31650"},
{
"firstname": "Genevieve",
"lastname": "Gamache",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=623265"},
{
"firstname": "Lynda",
"lastname": "Gammon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=174891"},
{
"firstname": "Dale",
"lastname": "Ganley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1085664"},
{
"firstname": "Sudhakar",
"lastname": "Ganti",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=981334"},
{
"firstname": "Katrina",
"lastname": "Gantly",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55453"},
{
"firstname": "Tony",
"lastname": "Gao",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1860745"},
{
"firstname": "Kseniya",
"lastname": "Garaschuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1649177"},
{
"firstname": "Mauricio",
"lastname": "Barrera",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1576434"},
{
"firstname": "James",
"lastname": "Gardner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1091962"},
{
"firstname": "Stephen",
"lastname": "Garlick",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1087392"},
{
"firstname": "Colin",
"lastname": "Garnett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1707396"},
{
"firstname": "David",
"lastname": "Gartrell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=176026"},
{
"firstname": "Steve",
"lastname": "Gaskin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1017502"},
{
"firstname": "Bill",
"lastname": "Gaston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11881"},
{
"firstname": "Adam",
"lastname": "Gaudry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1700659"},
{
"firstname": "Catherine",
"lastname": "Gaul",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93159"},
{
"firstname": "Melissa",
"lastname": "Gauthier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1868563"},
{
"firstname": "Jodie",
"lastname": "Gawryluk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1919299"},
{
"firstname": "Christine",
"lastname": "Geall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1520009"},
{
"firstname": "Fayez",
"lastname": "Gebali",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37690"},
{
"firstname": "Fran",
"lastname": "Gebhard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=335155"},
{
"firstname": "Deborah",
"lastname": "George",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=105575"},
{
"firstname": "Daniel",
"lastname": "German",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=51206"},
{
"firstname": "Suzanne",
"lastname": "Gessner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=251052"},
{
"firstname": "Michael",
"lastname": "Giampa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1545092"},
{
"firstname": "Celina",
"lastname": "Gibbs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1014580"},
{
"firstname": "Joe",
"lastname": "Gibson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39497"},
{
"firstname": "Jim",
"lastname": "Gibson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=724428"},
{
"firstname": "Steve",
"lastname": "Gibson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=167655"},
{
"firstname": "James",
"lastname": "Gifford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=866191"},
{
"firstname": "Robert",
"lastname": "Gifford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=88673"},
{
"firstname": "David",
"lastname": "Gifford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1839532"},
{
"firstname": "Bill",
"lastname": "Giglio",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54598"},
{
"firstname": "Gaelan",
"lastname": "Gilbert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1761142"},
{
"firstname": "David",
"lastname": "Giles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=113281"},
{
"firstname": "Mark",
"lastname": "Gillen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93868"},
{
"firstname": "Joan",
"lastname": "Gillie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1809256"},
{
"firstname": "Kathy",
"lastname": "Gillis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1398875"},
{
"firstname": "Isabelle",
"lastname": "Gingras",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1225641"},
{
"firstname": "Lisa",
"lastname": "Glass",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=953290"},
{
"firstname": "Terry",
"lastname": "Glavin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1703897"},
{
"firstname": "Simon",
"lastname": "Glezos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1222329"},
{
"firstname": "Barry",
"lastname": "Glickman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1593851"},
{
"firstname": "Ryan",
"lastname": "Godwin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1671036"},
{
"firstname": "Judith",
"lastname": "Goertzen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1585613"},
{
"firstname": "Anthony",
"lastname": "Goerzen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=859625"},
{
"firstname": "Colin",
"lastname": "Goldblatt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1805673"},
{
"firstname": "Martin",
"lastname": "Golder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1302084"},
{
"firstname": "Jonathan",
"lastname": "Goldman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1255037"},
{
"firstname": "Bram",
"lastname": "Goldwater",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=96010"},
{
"firstname": "Peter",
"lastname": "Golz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65569"},
{
"firstname": "Valerie",
"lastname": "Gonzales",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55088"},
{
"firstname": "Bruce",
"lastname": "Gooch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1017978"},
{
"firstname": "Amy",
"lastname": "Gooch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1113546"},
{
"firstname": "David",
"lastname": "Good",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=639570"},
{
"firstname": "Reuven",
"lastname": "Gordon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=237584"},
{
"firstname": "Hugh",
"lastname": "Gordon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1397923"},
{
"firstname": "Iris",
"lastname": "Gordon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1960112"},
{
"firstname": "Noel",
"lastname": "Gough",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=748229"},
{
"firstname": "Lisa",
"lastname": "Gould",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29078"},
{
"firstname": "John",
"lastname": "Gould",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=255578"},
{
"firstname": "Tatiana",
"lastname": "Gounko",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1799483"},
{
"firstname": "Purnima",
"lastname": "Govindarajulu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=885734"},
{
"firstname": "St",
"lastname": "Goyette",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=976489"},
{
"firstname": "Stefanie",
"lastname": "Grab",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1428098"},
{
"firstname": "Daniel",
"lastname": "Grace",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1248554"},
{
"firstname": "Alfonso",
"lastname": "Saz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1619672"},
{
"firstname": "Chris",
"lastname": "Graham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=384154"},
{
"firstname": "Rebecca",
"lastname": "Grant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38340"},
{
"firstname": "Patrick",
"lastname": "Grant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27049"},
{
"firstname": "Mariel",
"lastname": "Grant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45594"},
{
"firstname": "Garry",
"lastname": "Gray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1983875"},
{
"firstname": "Nelson",
"lastname": "Gray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=965377"},
{
"firstname": "Jaquie",
"lastname": "Green",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=417291"},
{
"firstname": "Don",
"lastname": "Greene",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1438918"},
{
"firstname": "Donald",
"lastname": "Greene",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1440334"},
{
"firstname": "John",
"lastname": "Greene",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=299894"},
{
"firstname": "Lynn",
"lastname": "Greenhough",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=898544"},
{
"firstname": "Linda",
"lastname": "Gregory",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=189796"},
{
"firstname": "Patrick",
"lastname": "Gregory",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=481575"},
{
"firstname": "Kathleen",
"lastname": "Gregory",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250558"},
{
"firstname": "Narine",
"lastname": "Grigoryan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1908557"},
{
"firstname": "Carl",
"lastname": "Grindley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54883"},
{
"firstname": "Joseph",
"lastname": "Grossi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1266696"},
{
"firstname": "Frederick",
"lastname": "Grouzet",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=965889"},
{
"firstname": "Elizabeth",
"lastname": "White",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1150505"},
{
"firstname": "Werner",
"lastname": "Grundlingh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=901556"},
{
"firstname": "Elisabeth",
"lastname": "Gugl",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330440"},
{
"firstname": "Aaron",
"lastname": "Gulliver",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36178"},
{
"firstname": "Jutta",
"lastname": "Gutberlet",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=71761"},
{
"firstname": "Allison",
"lastname": "Habkirk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1131985"},
{
"firstname": "Jeremy",
"lastname": "Hackett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1483697"},
{
"firstname": "James",
"lastname": "Haddow",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=64643"},
{
"firstname": "Allyson",
"lastname": "Hadwin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=325077"},
{
"firstname": "Yvonne",
"lastname": "Haist",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=31251"},
{
"firstname": "James",
"lastname": "Hale",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1541063"},
{
"firstname": "Helga",
"lastname": "Hallgrimsdottir",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=184838"},
{
"firstname": "Brittany",
"lastname": "Duncan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1889455"},
{
"firstname": "Cliff",
"lastname": "Haman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1385777"},
{
"firstname": "M",
"lastname": "Hamilton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=387391"},
{
"firstname": "Roberta",
"lastname": "Hamme",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1083429"},
{
"firstname": "Edd",
"lastname": "Hammill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1299978"},
{
"firstname": "Mitchell",
"lastname": "Hammond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=504253"},
{
"firstname": "BO",
"lastname": "Hansen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1479386"},
{
"firstname": "Jordan",
"lastname": "Hanson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=776441"},
{
"firstname": "Catherine",
"lastname": "Harding",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1974526"},
{
"firstname": "Catherine",
"lastname": "Harding",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76551"},
{
"firstname": "Linda",
"lastname": "Hardy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89227"},
{
"firstname": "Joan",
"lastname": "Harkness",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=704747"},
{
"firstname": "David",
"lastname": "Harrison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=968186"},
{
"firstname": "Alisa",
"lastname": "Harrison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=822666"},
{
"firstname": "Donna",
"lastname": "Harrison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=888075"},
{
"firstname": "Kindra",
"lastname": "Hart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1585159"},
{
"firstname": "Kim",
"lastname": "Wensley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27913"},
{
"firstname": "C",
"lastname": "Harvey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=629365"},
{
"firstname": "Timothy",
"lastname": "Haskett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=88715"},
{
"firstname": "Melissa",
"lastname": "Hauzer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250553"},
{
"firstname": "Barbara",
"lastname": "Hawkins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107115"},
{
"firstname": "Susan",
"lastname": "Hawkins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1286318"},
{
"firstname": "Craig",
"lastname": "Hawryshyn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=99584"},
{
"firstname": "Virginia",
"lastname": "Hayes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=911847"},
{
"firstname": "Martha",
"lastname": "Haylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28696"},
{
"firstname": "Yuko",
"lastname": "Heath",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=220295"},
{
"firstname": "Joelene",
"lastname": "Heathcote",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1856132"},
{
"firstname": "Derek",
"lastname": "Heathfield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1710331"},
{
"firstname": "Richard",
"lastname": "Hebda",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1289753"},
{
"firstname": "Alan",
"lastname": "Hedley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=78318"},
{
"firstname": "Caren",
"lastname": "Helbing",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=23253"},
{
"firstname": "Rachel",
"lastname": "Hellner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1112654"},
{
"firstname": "Lisa",
"lastname": "Helps",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1474750"},
{
"firstname": "Eric",
"lastname": "Henderson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89685"},
{
"firstname": "Lee",
"lastname": "Henderson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1707295"},
{
"firstname": "Bryan",
"lastname": "Hendricks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89861"},
{
"firstname": "Bernard",
"lastname": "Henin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=104338"},
{
"firstname": "Sean",
"lastname": "Henry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1377873"},
{
"firstname": "William",
"lastname": "Henry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91524"},
{
"firstname": "Karoline",
"lastname": "Herbison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1003773"},
{
"firstname": "Emmanuel",
"lastname": "rique",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89402"},
{
"firstname": "Rodney",
"lastname": "Herring",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=645697"},
{
"firstname": "Carla",
"lastname": "Hesketh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76593"},
{
"firstname": "Denton",
"lastname": "Hewgill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92638"},
{
"firstname": "Thomas",
"lastname": "Heyd",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=66499"},
{
"firstname": "Robin",
"lastname": "Hicks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=98875"},
{
"firstname": "Matthew",
"lastname": "Hiebert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1952039"},
{
"firstname": "Sean",
"lastname": "Hier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=224121"},
{
"firstname": "Iain",
"lastname": "Higgins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91340"},
{
"firstname": "David",
"lastname": "Higgins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1144470"},
{
"firstname": "Eric",
"lastname": "Higgs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=836598"},
{
"firstname": "Ryan",
"lastname": "Hilperts",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1657135"},
{
"firstname": "John",
"lastname": "Hinde",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45720"},
{
"firstname": "Kylee",
"lastname": "Hingston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1595425"},
{
"firstname": "Dan",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=244122"},
{
"firstname": "Will",
"lastname": "Hintz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=287414"},
{
"firstname": "Brett",
"lastname": "Hirsch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1377672"},
{
"firstname": "Sharon",
"lastname": "Hobenshield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250457"},
{
"firstname": "Sharon",
"lastname": "Hoddinott",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1505979"},
{
"firstname": "Denise",
"lastname": "Hodgins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1886200"},
{
"firstname": "Harold",
"lastname": "Hoefle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1061926"},
{
"firstname": "Hendrik",
"lastname": "Hoekstra",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=574905"},
{
"firstname": "Fraser",
"lastname": "Hof",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=950375"},
{
"firstname": "Daniel",
"lastname": "Hoffman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107082"},
{
"firstname": "Cindy",
"lastname": "Holder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38577"},
{
"firstname": "Adrienne",
"lastname": "Holierhoek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669505"},
{
"firstname": "Ingrid",
"lastname": "Holmberg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=240790"},
{
"firstname": "Clay",
"lastname": "Holroyd",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=424038"},
{
"firstname": "Jacqueline",
"lastname": "Homel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1915296"},
{
"firstname": "Matthew",
"lastname": "Hooton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1744211"},
{
"firstname": "Timothy",
"lastname": "Hopper",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=112214"},
{
"firstname": "Ahmed",
"lastname": "Hoque",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1224710"},
{
"firstname": "Thomas",
"lastname": "Horber",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=703481"},
{
"firstname": "Dennis",
"lastname": "Hore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=977332"},
{
"firstname": "Michael",
"lastname": "Horie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1125206"},
{
"firstname": "Nigel",
"lastname": "Horspool",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=228369"},
{
"firstname": "Stacey",
"lastname": "Horton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1147775"},
{
"firstname": "Anna",
"lastname": "Hostman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=953291"},
{
"firstname": "Melanie",
"lastname": "Houston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=168638"},
{
"firstname": "Alice",
"lastname": "Mais",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1556296"},
{
"firstname": "Perry",
"lastname": "Howard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=408385"},
{
"firstname": "Lloyd",
"lastname": "Howard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=405149"},
{
"firstname": "Nigel",
"lastname": "Howard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1655118"},
{
"firstname": "Leah",
"lastname": "Howard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1308689"},
{
"firstname": "Cosmo",
"lastname": "Howard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=762282"},
{
"firstname": "Robert",
"lastname": "Howell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=111096"},
{
"firstname": "Travis",
"lastname": "Hreno",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=704078"},
{
"firstname": "Yvonne",
"lastname": "Hsieh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=460271"},
{
"firstname": "Li",
"lastname": "Huang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=842620"},
{
"firstname": "Jing",
"lastname": "Huang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75461"},
{
"firstname": "Matthew",
"lastname": "Huculak",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1810971"},
{
"firstname": "John",
"lastname": "Huculak",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1950456"},
{
"firstname": "Ralph",
"lastname": "Huenemann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54602"},
{
"firstname": "Tom",
"lastname": "Hukari",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=72856"},
{
"firstname": "Stephen",
"lastname": "Hume",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65353"},
{
"firstname": "Richard",
"lastname": "Humphreys",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40916"},
{
"firstname": "Jeanne",
"lastname": "Humphries",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1246021"},
{
"firstname": "Sandra",
"lastname": "Hundza",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1386607"},
{
"firstname": "Christa",
"lastname": "Hunfeld",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1827686"},
{
"firstname": "Ying",
"lastname": "Hung",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1196068"},
{
"firstname": "H",
"lastname": "Martinez",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1058238"},
{
"firstname": "Susan",
"lastname": "Huntley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1359726"},
{
"firstname": "Karen",
"lastname": "Hurley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1014251"},
{
"firstname": "Wanda",
"lastname": "Hurren",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1428616"},
{
"firstname": "Emma",
"lastname": "Hutchinson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=457731"},
{
"firstname": "David",
"lastname": "Huxtable",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1485041"},
{
"firstname": "Debby",
"lastname": "Ianson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1584854"},
{
"firstname": "Slim",
"lastname": "Ibrahim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1334369"},
{
"firstname": "Asato",
"lastname": "Ikeda",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1782471"},
{
"firstname": "Timothy",
"lastname": "Iles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=79447"},
{
"firstname": "Reinhard",
"lastname": "Illner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90906"},
{
"firstname": "R",
"lastname": "Ingham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=946752"},
{
"firstname": "Valerie",
"lastname": "Irvine",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1678440"},
{
"firstname": "Anne",
"lastname": "Irwin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=126119"},
{
"firstname": "Jude",
"lastname": "Isabella",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1845013"},
{
"firstname": "Edward",
"lastname": "Ishiguro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=17633"},
{
"firstname": "Ben",
"lastname": "Isitt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1235316"},
{
"firstname": "Scott",
"lastname": "Iverson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=237586"},
{
"firstname": "Lillanne",
"lastname": "Jackson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=819086"},
{
"firstname": "Lorna",
"lastname": "Jackson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11883"},
{
"firstname": "Christopher",
"lastname": "Jaeger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1479270"},
{
"firstname": "Klaus",
"lastname": "Jahn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1197907"},
{
"firstname": "Jens",
"lastname": "Jahnke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54899"},
{
"firstname": "Matt",
"lastname": "James",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89352"},
{
"firstname": "Rebecca",
"lastname": "Jamin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=906918"},
{
"firstname": "Mikael",
"lastname": "Jansson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1123288"},
{
"firstname": "Donna",
"lastname": "Jeffery",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=619562"},
{
"firstname": "Dennis",
"lastname": "Jelinski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=708545"},
{
"firstname": "Janelle",
"lastname": "Jenstad",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=272210"},
{
"firstname": "Lesley",
"lastname": "Jessop",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1416892"},
{
"firstname": "Clayton",
"lastname": "Jevne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1587835"},
{
"firstname": "Andrew",
"lastname": "Jirasek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=802095"},
{
"firstname": "Jason",
"lastname": "Jobin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1719244"},
{
"firstname": "Betty",
"lastname": "Johnson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54719"},
{
"firstname": "Rebecca",
"lastname": "Johnson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=31652"},
{
"firstname": "Stephen",
"lastname": "Johnston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=156267"},
{
"firstname": "David",
"lastname": "Johnston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39499"},
{
"firstname": "Doug",
"lastname": "Johnstone",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=545465"},
{
"firstname": "Colin",
"lastname": "Jones",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36254"},
{
"firstname": "Tamsin",
"lastname": "Jones",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1599148"},
{
"firstname": "Kelly",
"lastname": "Joss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=910675"},
{
"firstname": "Catherine",
"lastname": "Joyce",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91387"},
{
"firstname": "Goertzen",
"lastname": "Judith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1596128"},
{
"firstname": "Antoine",
"lastname": "Julien",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1588481"},
{
"firstname": "Martin",
"lastname": "Jun",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1512307"},
{
"firstname": "Kim",
"lastname": "Juniper",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1105394"},
{
"firstname": "Helena",
"lastname": "Kadlec",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95761"},
{
"firstname": "Lisa",
"lastname": "Kadonaga",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38066"},
{
"firstname": "Yuri",
"lastname": "Kagolovsky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76600"},
{
"firstname": "Justin",
"lastname": "Kalef",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=217058"},
{
"firstname": "Smaro",
"lastname": "Kamboureli",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43487"},
{
"firstname": "Piotr",
"lastname": "Kaminski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36618"},
{
"firstname": "Sunil",
"lastname": "Kaplash",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52636"},
{
"firstname": "Bruce",
"lastname": "Kapron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56570"},
{
"firstname": "Dean",
"lastname": "Karlen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=100946"},
{
"firstname": "William",
"lastname": "Kay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38678"},
{
"firstname": "Magdalena",
"lastname": "Kay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1073231"},
{
"firstname": "Stephanie",
"lastname": "Keane",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1224383"},
{
"firstname": "Mike",
"lastname": "Keddy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=939813"},
{
"firstname": "James",
"lastname": "Keefer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1425816"},
{
"firstname": "Richard",
"lastname": "Keeler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1586776"},
{
"firstname": "Janice",
"lastname": "Keliher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1489097"},
{
"firstname": "Arnold",
"lastname": "Keller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89329"},
{
"firstname": "Peter",
"lastname": "Keller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65294"},
{
"firstname": "Treava",
"lastname": "Kellington",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=297222"},
{
"firstname": "Erin",
"lastname": "Kelly",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1381999"},
{
"firstname": "Jamie",
"lastname": "Kemp",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1588030"},
{
"firstname": "Amelia",
"lastname": "Kennedy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1372232"},
{
"firstname": "Peter",
"lastname": "Kennedy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70467"},
{
"firstname": "Mary",
"lastname": "Kennedy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1793962"},
{
"firstname": "Sunni",
"lastname": "Keplash",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1386657"},
{
"firstname": "Duncan",
"lastname": "Kerkham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=422256"},
{
"firstname": "Kimberly",
"lastname": "Kerns",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1414158"},
{
"firstname": "Valerie",
"lastname": "Kerr",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1982327"},
{
"firstname": "Mary",
"lastname": "Kerr",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=108194"},
{
"firstname": "Joseph",
"lastname": "Kess",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30747"},
{
"firstname": "Kimball",
"lastname": "Ketsa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1014583"},
{
"firstname": "Omer",
"lastname": "Khan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1168230"},
{
"firstname": "Boualem",
"lastname": "Khouider",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=243466"},
{
"firstname": "Anne",
"lastname": "Kilbertus",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506091"},
{
"firstname": "Brady",
"lastname": "Kilough",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=891698"},
{
"firstname": "Sehjeong",
"lastname": "Kim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1266987"},
{
"firstname": "Mika",
"lastname": "Kimura",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36155"},
{
"firstname": "Valerie",
"lastname": "King",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56569"},
{
"firstname": "Gerald",
"lastname": "King",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=82223"},
{
"firstname": "Richard",
"lastname": "King",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35745"},
{
"firstname": "Christie",
"lastname": "King",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75828"},
{
"firstname": "Laurie",
"lastname": "Irani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42659"},
{
"firstname": "Bindon",
"lastname": "Kinghorn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=97409"},
{
"firstname": "Sandra",
"lastname": "Kirkham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=224909"},
{
"firstname": "Maria",
"lastname": "Kisel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1228085"},
{
"firstname": "Lynette",
"lastname": "Kissoon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1675243"},
{
"firstname": "Kaoru",
"lastname": "Kiyosawa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1003620"},
{
"firstname": "Jens",
"lastname": "Kjaerulff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=750163"},
{
"firstname": "Margaret",
"lastname": "Klatt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330445"},
{
"firstname": "Carrie",
"lastname": "Klatt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=237634"},
{
"firstname": "Saul",
"lastname": "Klein",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54677"},
{
"firstname": "David",
"lastname": "Klenmann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=843249"},
{
"firstname": "Marc",
"lastname": "Klimstra",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1672550"},
{
"firstname": "Eike",
"lastname": "Kluge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28328"},
{
"firstname": "Andre",
"lastname": "Klumb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1036819"},
{
"firstname": "Jody",
"lastname": "Klymak",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1504721"},
{
"firstname": "Hilary",
"lastname": "Knight",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38106"},
{
"firstname": "Anne",
"lastname": "Knoke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1616502"},
{
"firstname": "Karen",
"lastname": "Kobayashi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=186689"},
{
"firstname": "Matthew",
"lastname": "Koch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=393645"},
{
"firstname": "Kent",
"lastname": "Kodalen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=615555"},
{
"firstname": "Freya",
"lastname": "Kodar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1002792"},
{
"firstname": "Joel",
"lastname": "Konrad",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1499408"},
{
"firstname": "Ben",
"lastname": "Koop",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=575347"},
{
"firstname": "Michelle",
"lastname": "Korall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=826496"},
{
"firstname": "Konrad",
"lastname": "Kordoski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=103991"},
{
"firstname": "Walter",
"lastname": "Kotorynski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38068"},
{
"firstname": "Pavel",
"lastname": "Kovtun",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1556739"},
{
"firstname": "Robert",
"lastname": "Kowalewski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90615"},
{
"firstname": "Robin",
"lastname": "Koytcheff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1839124"},
{
"firstname": "Ron",
"lastname": "Kozsan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1464997"},
{
"firstname": "Paul",
"lastname": "Kraeutner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1232911"},
{
"firstname": "Luanne",
"lastname": "Krawetz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89815"},
{
"firstname": "Adam",
"lastname": "Krawitz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1667017"},
{
"firstname": "Harald",
"lastname": "Krebs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=231769"},
{
"firstname": "Olav",
"lastname": "Krigolson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=255189"},
{
"firstname": "Arthur",
"lastname": "Kroker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=250165"},
{
"firstname": "Geof",
"lastname": "Kron",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=909829"},
{
"firstname": "Gary",
"lastname": "Kuchar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=525722"},
{
"firstname": "Stacy",
"lastname": "Kuiack",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=505852"},
{
"firstname": "Taneli",
"lastname": "Kukkonen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=300109"},
{
"firstname": "Ramani",
"lastname": "Kumar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=229050"},
{
"firstname": "Alok",
"lastname": "Kumar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=419519"},
{
"firstname": "Eric",
"lastname": "Kunze",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=734653"},
{
"firstname": "Alex",
"lastname": "Kuo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1442030"},
{
"firstname": "Estelle",
"lastname": "Kurier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1596252"},
{
"firstname": "Helen",
"lastname": "Kurki",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1152030"},
{
"firstname": "Kristen",
"lastname": "Kvakic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1784587"},
{
"firstname": "Erik",
"lastname": "Kwakkel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=848512"},
{
"firstname": "Harry",
"lastname": "Kwok",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36208"},
{
"firstname": "John",
"lastname": "Kyle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54605"},
{
"firstname": "Marcelo",
"lastname": "Laca",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77631"},
{
"firstname": "Terri",
"lastname": "Lacourse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1060121"},
{
"firstname": "Ariel",
"lastname": "Lade",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=696028"},
{
"firstname": "Mark",
"lastname": "Laidlaw",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=902730"},
{
"firstname": "Angelique",
"lastname": "Lalonde",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1791735"},
{
"firstname": "Chris",
"lastname": "Lalonde",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=50400"},
{
"firstname": "Yin",
"lastname": "Lam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=319537"},
{
"firstname": "Todd",
"lastname": "Lambeth",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1070893"},
{
"firstname": "Mark",
"lastname": "Lamont",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=614820"},
{
"firstname": "Yin",
"lastname": "Lan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1241091"},
{
"firstname": "Patrick",
"lastname": "Lane",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76063"},
{
"firstname": "Monika",
"lastname": "Langer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45323"},
{
"firstname": "John",
"lastname": "Langford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=868068"},
{
"firstname": "Stewart",
"lastname": "Langton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=85459"},
{
"firstname": "Trevor",
"lastname": "Lantz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1536063"},
{
"firstname": "Marc",
"lastname": "Lapprand",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=94693"},
{
"firstname": "Daniel",
"lastname": "Laskarin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=250187"},
{
"firstname": "Suzan",
"lastname": "Last",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=780427"},
{
"firstname": "Francis",
"lastname": "Lau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=204960"},
{
"firstname": "Lara",
"lastname": "Lauzon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=540602"},
{
"firstname": "Tracey",
"lastname": "Lavoie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1158235"},
{
"firstname": "Jamie",
"lastname": "Lawson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=550148"},
{
"firstname": "David",
"lastname": "Leach",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=584801"},
{
"firstname": "Brian",
"lastname": "Leacock",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1541174"},
{
"firstname": "Bonnie",
"lastname": "Leadbeater",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56496"},
{
"firstname": "Larry",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75415"},
{
"firstname": "John",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1238735"},
{
"firstname": "Henry",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1892536"},
{
"firstname": "Sherry",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=811239"},
{
"firstname": "Karen",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1800918"},
{
"firstname": "Vivian",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=635004"},
{
"firstname": "Sharon",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1077090"},
{
"firstname": "Jo",
"lastname": "Lee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=108536"},
{
"firstname": "Dave",
"lastname": "Lefebure",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=925807"},
{
"firstname": "Michel",
"lastname": "Lefebvre",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42707"},
{
"firstname": "Catherine",
"lastname": "Leger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1553031"},
{
"firstname": "Mary",
"lastname": "Leighton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42674"},
{
"firstname": "Sara",
"lastname": "Leiserson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89817"},
{
"firstname": "Tanya",
"lastname": "Lentz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1186587"},
{
"firstname": "Lucinda",
"lastname": "Leonard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=450971"},
{
"firstname": "Annalee",
"lastname": "Lepp",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107644"},
{
"firstname": "Kenneth",
"lastname": "Leslie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1485048"},
{
"firstname": "Mary",
"lastname": "Lesperance",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=233255"},
{
"firstname": "Hester",
"lastname": "Lessard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27906"},
{
"firstname": "Riza",
"lastname": "Lestari",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1387356"},
{
"firstname": "Dan",
"lastname": "Lett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1783107"},
{
"firstname": "Aegean",
"lastname": "Leung",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1542800"},
{
"firstname": "Paul",
"lastname": "Levie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=110704"},
{
"firstname": "David",
"lastname": "Levin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28583"},
{
"firstname": "Yisrael",
"lastname": "Levin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=973214"},
{
"firstname": "Vic",
"lastname": "Levson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=755365"},
{
"firstname": "Susan",
"lastname": "Lewis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=50404"},
{
"firstname": "Mitchell",
"lastname": "Hammond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=477300"},
{
"firstname": "Beryl",
"lastname": "LI",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1496566"},
{
"firstname": "Kin",
"lastname": "Li",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37400"},
{
"firstname": "Lichen",
"lastname": "Liang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1920672"},
{
"firstname": "Peter",
"lastname": "Liddell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89253"},
{
"firstname": "Christian",
"lastname": "Lieb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=540356"},
{
"firstname": "Tim",
"lastname": "Lilburn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=634055"},
{
"firstname": "Paul",
"lastname": "Lim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=22995"},
{
"firstname": "Hua",
"lastname": "Lin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95032"},
{
"firstname": "Minghua",
"lastname": "Lin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1879086"},
{
"firstname": "Tsung",
"lastname": "Lin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1463820"},
{
"firstname": "Allana",
"lastname": "Lindgren",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1330442"},
{
"firstname": "Jennifer",
"lastname": "Lindquist",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1826559"},
{
"firstname": "Evert",
"lastname": "Lindquist",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=313779"},
{
"firstname": "Peter",
"lastname": "Lindsay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1603690"},
{
"firstname": "Stephen",
"lastname": "Lindsay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=125708"},
{
"firstname": "DS",
"lastname": "Lindsay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=860758"},
{
"firstname": "Robert",
"lastname": "Lipson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1665602"},
{
"firstname": "Kathlyn",
"lastname": "Liscomb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76555"},
{
"firstname": "Paul",
"lastname": "Lisson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1791602"},
{
"firstname": "Cole",
"lastname": "Little",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1327776"},
{
"firstname": "Rich",
"lastname": "Little",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=469527"},
{
"firstname": "Warren",
"lastname": "Little",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55017"},
{
"firstname": "William",
"lastname": "Little",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38044"},
{
"firstname": "Cedric",
"lastname": "Littlewood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30155"},
{
"firstname": "Mingxi",
"lastname": "Liu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1985222"},
{
"firstname": "Nigel",
"lastname": "Livingston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1621310"},
{
"firstname": "Sharon",
"lastname": "Livingstone",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1181476"},
{
"firstname": "Steven",
"lastname": "Lonergan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1675184"},
{
"firstname": "Stephen",
"lastname": "Lonergan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=126530"},
{
"firstname": "Donna",
"lastname": "Long",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1652502"},
{
"firstname": "Eduardo",
"lastname": "Loos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93102"},
{
"firstname": "Claudia",
"lastname": "Lorenz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1910792"},
{
"firstname": "Daniella",
"lastname": "Lorenzi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55061"},
{
"firstname": "Mary",
"lastname": "Lougheed",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=226574"},
{
"firstname": "Margot",
"lastname": "Louis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91408"},
{
"firstname": "Brad",
"lastname": "Love",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=787875"},
{
"firstname": "Janet",
"lastname": "Love",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1178824"},
{
"firstname": "Wu",
"lastname": "Lu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=58312"},
{
"firstname": "Tao",
"lastname": "Lu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1303765"},
{
"firstname": "John",
"lastname": "Lucas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1112445"},
{
"firstname": "Martina",
"lastname": "Lui",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1651869"},
{
"firstname": "Michael",
"lastname": "Lukas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1866232"},
{
"firstname": "Julian",
"lastname": "Lum",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1876736"},
{
"firstname": "John",
"lastname": "Luna",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1060232"},
{
"firstname": "Scott",
"lastname": "Lunney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1476131"},
{
"firstname": "Horace",
"lastname": "Luong",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1118081"},
{
"firstname": "John",
"lastname": "Lutz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=51282"},
{
"firstname": "Dale",
"lastname": "Lyons",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1033785"},
{
"firstname": "Michael",
"lastname": "Gonigle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=821896"},
{
"firstname": "Junling",
"lastname": "Ma",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=948590"},
{
"firstname": "Sachen",
"lastname": "MacDonald",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55228"},
{
"firstname": "Carol",
"lastname": "MacDonald",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1567357"},
{
"firstname": "Andrew",
"lastname": "MacDougall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1869662"},
{
"firstname": "Samantha",
"lastname": "MacFarlane",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1985356"},
{
"firstname": "Emmett",
"lastname": "MacFarlane",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1665407"},
{
"firstname": "Gary",
"lastname": "MacGillivray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92078"},
{
"firstname": "Teresa",
"lastname": "Macias",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669574"},
{
"firstname": "Josephine",
"lastname": "MacIntosh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=819217"},
{
"firstname": "Pat",
"lastname": "MacKenzie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=767804"},
{
"firstname": "Quentin",
"lastname": "Mackie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=34181"},
{
"firstname": "Carla",
"lastname": "MacLean",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=862138"},
{
"firstname": "Brock",
"lastname": "MacLeod",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=716778"},
{
"firstname": "Colin",
"lastname": "MacLeod",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11876"},
{
"firstname": "Joan",
"lastname": "MacLeod",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=584805"},
{
"firstname": "Sheryl",
"lastname": "MacMath",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1158651"},
{
"firstname": "Daphne",
"lastname": "MacNaughton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=929928"},
{
"firstname": "Paul",
"lastname": "MacRae",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=786242"},
{
"firstname": "Allison",
"lastname": "Maffey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1884514"},
{
"firstname": "Moussa",
"lastname": "Magassa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1504990"},
{
"firstname": "Doug",
"lastname": "Magnuson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1776858"},
{
"firstname": "Rachel",
"lastname": "Magnusson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1803184"},
{
"firstname": "Warren",
"lastname": "Magnusson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=84314"},
{
"firstname": "Michi",
"lastname": "Main",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=954513"},
{
"firstname": "Basma",
"lastname": "Majerbi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=642424"},
{
"firstname": "Mia",
"lastname": "Maki",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1244828"},
{
"firstname": "Emily",
"lastname": "Malcolm",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951045"},
{
"firstname": "Amanda",
"lastname": "Malloch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1442159"},
{
"firstname": "David",
"lastname": "Mandel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38369"},
{
"firstname": "Matthew",
"lastname": "Manera",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=44765"},
{
"firstname": "Barry",
"lastname": "Mangrill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506704"},
{
"firstname": "Eric",
"lastname": "Manning",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57503"},
{
"firstname": "Liz",
"lastname": "Manning",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1110261"},
{
"firstname": "Michael",
"lastname": "Manson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=946747"},
{
"firstname": "Josh",
"lastname": "Manzer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1785004"},
{
"firstname": "Andrew",
"lastname": "",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951692"},
{
"firstname": "Claude",
"lastname": "Marchessault",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1294698"},
{
"firstname": "Dimitrios",
"lastname": "Marinakis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1469596"},
{
"firstname": "William",
"lastname": "Markham",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=63596"},
{
"firstname": "Nat",
"lastname": "Markin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1797665"},
{
"firstname": "Lynne",
"lastname": "Marks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91477"},
{
"firstname": "Peter",
"lastname": "Marrs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=17632"},
{
"firstname": "Daniel",
"lastname": "Marshall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=781464"},
{
"firstname": "Joan",
"lastname": "Martin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92759"},
{
"firstname": "Stephen",
"lastname": "Martin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1788771"},
{
"firstname": "Steve",
"lastname": "Martin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=293136"},
{
"firstname": "Luanne",
"lastname": "Martineau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=209318"},
{
"firstname": "Cristina",
"lastname": "Martinez",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1307765"},
{
"firstname": "Andrew",
"lastname": "Marton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1930907"},
{
"firstname": "Burak",
"lastname": "Martonalti",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1693625"},
{
"firstname": "Roswitha",
"lastname": "Marx",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92058"},
{
"firstname": "Kerry",
"lastname": "Mason",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=506156"},
{
"firstname": "Joost",
"lastname": "Massolt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1810520"},
{
"firstname": "Michael",
"lastname": "Masson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330108"},
{
"firstname": "Darcy",
"lastname": "Matthews",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1921046"},
{
"firstname": "Margo",
"lastname": "Matwychuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70005"},
{
"firstname": "Aaron",
"lastname": "Mauro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1842955"},
{
"firstname": "George",
"lastname": "May",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37543"},
{
"firstname": "Margie",
"lastname": "Mayfield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1137582"},
{
"firstname": "Luke",
"lastname": "Maynard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1374688"},
{
"firstname": "Douglas",
"lastname": "Maynard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250644"},
{
"firstname": "Asit",
"lastname": "Mazumder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1261959"},
{
"firstname": "Jennifer",
"lastname": "Mazur",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1070977"},
{
"firstname": "Jacqueline",
"lastname": "McAdam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1533893"},
{
"firstname": "Gabriela",
"lastname": "McBee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75469"},
{
"firstname": "James",
"lastname": "McBride",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=50374"},
{
"firstname": "Shanne",
"lastname": "McCaffery",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=769819"},
{
"firstname": "Sandra",
"lastname": "McCallum",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1746498"},
{
"firstname": "Lawrence",
"lastname": "McCann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89451"},
{
"firstname": "Lindsay",
"lastname": "McCardle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1654275"},
{
"firstname": "Murdith",
"lastname": "McClean",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1435392"},
{
"firstname": "Jason",
"lastname": "McClure",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1486509"},
{
"firstname": "Alan",
"lastname": "McConnachie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1036743"},
{
"firstname": "David",
"lastname": "McCutcheon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=74710"},
{
"firstname": "Graham",
"lastname": "McDonough",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1149494"},
{
"firstname": "Ted",
"lastname": "McDorman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27912"},
{
"firstname": "Steve",
"lastname": "McGehee",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1233646"},
{
"firstname": "Martha",
"lastname": "McGinnis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1482155"},
{
"firstname": "Michael",
"lastname": "McGrail",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75816"},
{
"firstname": "Mike",
"lastname": "McGrath",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1788486"},
{
"firstname": "Geoffrey",
"lastname": "McGregor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1842691"},
{
"firstname": "Erin",
"lastname": "McGuire",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1472311"},
{
"firstname": "Michael",
"lastname": "McGuire",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=390979"},
{
"firstname": "Peter",
"lastname": "McGuire",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=121861"},
{
"firstname": "Scott",
"lastname": "McIndoe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=807758"},
{
"firstname": "Claire",
"lastname": "McKenzie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54494"},
{
"firstname": "Andrea",
"lastname": "McKenzie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=484197"},
{
"firstname": "Dave",
"lastname": "McKercher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=244253"},
{
"firstname": "Angus",
"lastname": "McLaren",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52639"},
{
"firstname": "Lianne",
"lastname": "McLarty",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11888"},
{
"firstname": "Erin",
"lastname": "Jenkins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=296553"},
{
"firstname": "Eric",
"lastname": "McLay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1965377"},
{
"firstname": "Melissa",
"lastname": "McLean",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1918162"},
{
"firstname": "Mike",
"lastname": "McLean",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1450027"},
{
"firstname": "Elizabeth",
"lastname": "McLeish",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77301"},
{
"firstname": "Martha",
"lastname": "McMahon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90908"},
{
"firstname": "Kirk",
"lastname": "McNally",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=997789"},
{
"firstname": "John",
"lastname": "Measor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=514241"},
{
"firstname": "David",
"lastname": "Medler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1549251"},
{
"firstname": "Alan",
"lastname": "Mehlenbacher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1080755"},
{
"firstname": "Raj",
"lastname": "Mehta",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89630"},
{
"firstname": "Sandra",
"lastname": "Meigs",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95462"},
{
"firstname": "Steven",
"lastname": "Meikle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1385781"},
{
"firstname": "Katrin",
"lastname": "Meissner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1146911"},
{
"firstname": "John",
"lastname": "Meldrum",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1064925"},
{
"firstname": "Robin",
"lastname": "Mellway",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1212351"},
{
"firstname": "Kinga",
"lastname": "Menu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=770478"},
{
"firstname": "D",
"lastname": "Merrett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1032669"},
{
"firstname": "Devin",
"lastname": "Michell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1439158"},
{
"firstname": "Robert",
"lastname": "Miers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92641"},
{
"firstname": "Kirsten",
"lastname": "Mikkelson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1183591"},
{
"firstname": "Robert",
"lastname": "Miles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=831856"},
{
"firstname": "Jessica",
"lastname": "Miles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1485049"},
{
"firstname": "Todd",
"lastname": "Milford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=794638"},
{
"firstname": "David",
"lastname": "Millar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=63364"},
{
"firstname": "Gordon",
"lastname": "Miller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1622509"},
{
"firstname": "Michael",
"lastname": "Miller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=51133"},
{
"firstname": "Eric",
"lastname": "Miller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27048"},
{
"firstname": "Gary",
"lastname": "Miller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=62434"},
{
"firstname": "Rena",
"lastname": "Miller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=388398"},
{
"firstname": "Laurain",
"lastname": "Mills",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35747"},
{
"firstname": "Nikola",
"lastname": "Milutinovic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1029051"},
{
"firstname": "Marcus",
"lastname": "Milwright",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76559"},
{
"firstname": "Jeewon",
"lastname": "Min",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1803547"},
{
"firstname": "Darren",
"lastname": "Minifie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1264084"},
{
"firstname": "Santosh",
"lastname": "Misra",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29909"},
{
"firstname": "Lisa",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=11878"},
{
"firstname": "Marjorie",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95075"},
{
"firstname": "Ron",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38338"},
{
"firstname": "Reg",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43799"},
{
"firstname": "Devin",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1293782"},
{
"firstname": "Tim",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1603694"},
{
"firstname": "Liam",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1646194"},
{
"firstname": "Judith",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91413"},
{
"firstname": "J",
"lastname": "Mitchell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=958044"},
{
"firstname": "Farouk",
"lastname": "Mitha",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=375321"},
{
"firstname": "Wayne",
"lastname": "Mitic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=332481"},
{
"firstname": "Maryam",
"lastname": "Mizani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=987169"},
{
"firstname": "Matthew",
"lastname": "Moffitt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=563601"},
{
"firstname": "Paul",
"lastname": "Mohapel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=742455"},
{
"firstname": "Joana",
"lastname": "Mohapel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1994366"},
{
"firstname": "Cheryl",
"lastname": "Iersel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=108098"},
{
"firstname": "Doug",
"lastname": "Mollard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=247134"},
{
"firstname": "Adam",
"lastname": "Monahan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=23002"},
{
"firstname": "John",
"lastname": "Money",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56612"},
{
"firstname": "Sylvie",
"lastname": "Mongeon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=896723"},
{
"firstname": "Peter",
"lastname": "Monk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1312425"},
{
"firstname": "Bruce",
"lastname": "Monkhouse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1469544"},
{
"firstname": "Alvaro",
"lastname": "Montenegro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=534267"},
{
"firstname": "Kathy",
"lastname": "Montgomery",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=226231"},
{
"firstname": "Michele",
"lastname": "Moore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1726495"},
{
"firstname": "Edward",
"lastname": "Moore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=98447"},
{
"firstname": "Alison",
"lastname": "Moran",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=890625"},
{
"firstname": "Anne",
"lastname": "Morand",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=474490"},
{
"firstname": "Bruce",
"lastname": "More",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=215754"},
{
"firstname": "Jeannine",
"lastname": "Moreau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1830704"},
{
"firstname": "Connie",
"lastname": "Morey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1112195"},
{
"firstname": "Christopher",
"lastname": "Morgan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89235"},
{
"firstname": "Charles",
"lastname": "Morgan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=74569"},
{
"firstname": "Chris",
"lastname": "Morier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77298"},
{
"firstname": "Terence",
"lastname": "Morley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=79448"},
{
"firstname": "Jonny",
"lastname": "Morris",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1536722"},
{
"firstname": "Carl",
"lastname": "Mosk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27920"},
{
"firstname": "Pamela",
"lastname": "Moss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=465431"},
{
"firstname": "Andrea",
"lastname": "Mueller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=996633"},
{
"firstname": "Ulrich",
"lastname": "Mueller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=351193"},
{
"firstname": "D",
"lastname": "Muir",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1746246"},
{
"firstname": "Hausi",
"lastname": "Muller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32476"},
{
"firstname": "Benjamin",
"lastname": "Muller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=287882"},
{
"firstname": "Greg",
"lastname": "Mulligan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1144401"},
{
"firstname": "Shane",
"lastname": "Mulligan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=508790"},
{
"firstname": "Sangeetha",
"lastname": "Munikrishnaiah",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1263364"},
{
"firstname": "Jennifer",
"lastname": "Murdoch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=787882"},
{
"firstname": "Matt",
"lastname": "Murphy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1753886"},
{
"firstname": "Andrew",
"lastname": "Murray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42596"},
{
"firstname": "Susan",
"lastname": "Musgrave",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1156291"},
{
"firstname": "Jon",
"lastname": "Muzio",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=94835"},
{
"firstname": "Christine",
"lastname": "Mynhardt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77630"},
{
"firstname": "Wendy",
"lastname": "Myrvold",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=10604"},
{
"firstname": "Ben",
"lastname": "Nadler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1606071"},
{
"firstname": "James",
"lastname": "Nahachewsky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1555223"},
{
"firstname": "Naohiro",
"lastname": "Nakamura",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1184339"},
{
"firstname": "Sang",
"lastname": "Nam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54603"},
{
"firstname": "Maryam",
"lastname": "Namazi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1540543"},
{
"firstname": "S",
"lastname": "Nandi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1602800"},
{
"firstname": "Justin",
"lastname": "Nankivell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=821889"},
{
"firstname": "Francis",
"lastname": "Nano",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29904"},
{
"firstname": "Simon",
"lastname": "Nantais",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1596623"},
{
"firstname": "Valerie",
"lastname": "Napoleon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1820240"},
{
"firstname": "Syed",
"lastname": "Naqvi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1026403"},
{
"firstname": "Roshni",
"lastname": "Narain",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1109322"},
{
"firstname": "Anita",
"lastname": "Narwani",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=892629"},
{
"firstname": "Raad",
"lastname": "Nashmi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1314834"},
{
"firstname": "Jessica",
"lastname": "Nasica",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=471241"},
{
"firstname": "Hossein",
"lastname": "Nassaji",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=260977"},
{
"firstname": "Farouk",
"lastname": "Nathoo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=800969"},
{
"firstname": "Julio",
"lastname": "Navarro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90641"},
{
"firstname": "PJ",
"lastname": "Naylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=923429"},
{
"firstname": "Wendy",
"lastname": "Neander",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1813480"},
{
"firstname": "Dawn",
"lastname": "Neill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43484"},
{
"firstname": "Dave",
"lastname": "Nelles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=307158"},
{
"firstname": "John",
"lastname": "Nelson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=554132"},
{
"firstname": "Chris",
"lastname": "Nelson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1540029"},
{
"firstname": "Trisalyn",
"lastname": "Nelson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=725335"},
{
"firstname": "Mark",
"lastname": "Neufeld",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1452405"},
{
"firstname": "Candice",
"lastname": "Neveu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1596840"},
{
"firstname": "Stephen",
"lastname": "Neville",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=234911"},
{
"firstname": "C",
"lastname": "Nevue",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=994951"},
{
"firstname": "John",
"lastname": "Newcomb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92042"},
{
"firstname": "Andrew",
"lastname": "Newcombe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1453845"},
{
"firstname": "Tara",
"lastname": "Ney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=800375"},
{
"firstname": "Ignace",
"lastname": "Ng",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28683"},
{
"firstname": "Ernest",
"lastname": "Ng",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1006360"},
{
"firstname": "Sada",
"lastname": "Niang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93557"},
{
"firstname": "Bogdan",
"lastname": "Nica",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1334385"},
{
"firstname": "Emma",
"lastname": "Allison",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1965936"},
{
"firstname": "Douglas",
"lastname": "Nichols",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=79450"},
{
"firstname": "Robert",
"lastname": "Nichols",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1078318"},
{
"firstname": "Tara",
"lastname": "Nicholson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1676739"},
{
"firstname": "Dawn",
"lastname": "Nickel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=766387"},
{
"firstname": "Jeffrey",
"lastname": "Niehaus",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1366620"},
{
"firstname": "Olaf",
"lastname": "Niemann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89607"},
{
"firstname": "Milo",
"lastname": "Nikolic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=714244"},
{
"firstname": "Jean",
"lastname": "Noble",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=467794"},
{
"firstname": "Rajeev",
"lastname": "Nongpiur",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1880711"},
{
"firstname": "Hiroko",
"lastname": "Noro",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95033"},
{
"firstname": "April",
"lastname": "Nowell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29085"},
{
"firstname": "Michael",
"lastname": "Nowlin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54882"},
{
"firstname": "Mark",
"lastname": "Nugent",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=909028"},
{
"firstname": "Catherine",
"lastname": "Nutting",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1115119"},
{
"firstname": "Vicki",
"lastname": "Nygaard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38108"},
{
"firstname": "Judith",
"lastname": "Nylvek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75468"},
{
"firstname": "Christine",
"lastname": "Bonsawin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1430129"},
{
"firstname": "Martha",
"lastname": "Brien",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27917"},
{
"firstname": "Ian",
"lastname": "Connell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=261476"},
{
"firstname": "Paul",
"lastname": "Connor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=665559"},
{
"firstname": "Kristy",
"lastname": "Connor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=424860"},
{
"firstname": "Gerard",
"lastname": "Leary",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=804448"},
{
"firstname": "Pat",
"lastname": "Riley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=74733"},
{
"firstname": "Jennifer",
"lastname": "Oakes",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1576440"},
{
"firstname": "Donna",
"lastname": "Ogden",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1192388"},
{
"firstname": "Richard",
"lastname": "Ogmundson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=257436"},
{
"firstname": "Dale",
"lastname": "Olesky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=173135"},
{
"firstname": "John",
"lastname": "Oleson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43486"},
{
"firstname": "Stephanie",
"lastname": "Olsen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=383709"},
{
"firstname": "Linda",
"lastname": "Olson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=48735"},
{
"firstname": "Treena",
"lastname": "Orchard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1149072"},
{
"firstname": "Todd",
"lastname": "Ormiston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=755499"},
{
"firstname": "Timothy",
"lastname": "Ormond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1325684"},
{
"firstname": "Erin",
"lastname": "Ormund",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=955304"},
{
"firstname": "Heather",
"lastname": "Orr",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1144058"},
{
"firstname": "Svetlana",
"lastname": "Oshkai",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=458299"},
{
"firstname": "Aleck",
"lastname": "Ostry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1298152"},
{
"firstname": "David",
"lastname": "Oswald",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1689526"},
{
"firstname": "Keiko",
"lastname": "Ota",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35753"},
{
"firstname": "Russ",
"lastname": "Ovans",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=316915"},
{
"firstname": "Peter",
"lastname": "Ove",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1248289"},
{
"firstname": "Cameron",
"lastname": "Owens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1593322"},
{
"firstname": "Marcia",
"lastname": "Ozier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=231674"},
{
"firstname": "Irina",
"lastname": "Paci",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1041133"},
{
"firstname": "Veronica",
"lastname": "Ketchabaw",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=413617"},
{
"firstname": "Vern",
"lastname": "Paetkau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=189834"},
{
"firstname": "Louise",
"lastname": "Page",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89606"},
{
"firstname": "Beth",
"lastname": "Page",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1601086"},
{
"firstname": "Marlo",
"lastname": "Paige",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1404621"},
{
"firstname": "Jianping",
"lastname": "Pan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=963651"},
{
"firstname": "Sylvia",
"lastname": "Pantaleo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=715186"},
{
"firstname": "Chris",
"lastname": "Papadopoulos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1437935"},
{
"firstname": "Karla",
"lastname": "Paplawski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250554"},
{
"firstname": "Johanne",
"lastname": "Paquette",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1303837"},
{
"firstname": "Laura",
"lastname": "Parisi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=262356"},
{
"firstname": "Lara",
"lastname": "Parisi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1957342"},
{
"firstname": "Edward",
"lastname": "Park",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=698253"},
{
"firstname": "Adam",
"lastname": "Parkin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=926985"},
{
"firstname": "June",
"lastname": "Parmley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=928494"},
{
"firstname": "Mitchell",
"lastname": "Parr",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1920095"},
{
"firstname": "Mitchell",
"lastname": "Parry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1920097"},
{
"firstname": "Mitch",
"lastname": "Parry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89840"},
{
"firstname": "Kristin",
"lastname": "Parton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=970323"},
{
"firstname": "Sara",
"lastname": "Pash",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=73315"},
{
"firstname": "Jean",
"lastname": "Passy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1725991"},
{
"firstname": "Anna",
"lastname": "Patten",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1916544"},
{
"firstname": "Glenn",
"lastname": "Patterson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1235726"},
{
"firstname": "Heather",
"lastname": "Pattullo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=502548"},
{
"firstname": "Bart",
"lastname": "Paudyn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1463107"},
{
"firstname": "Dorothy",
"lastname": "Paul",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89664"},
{
"firstname": "Leina",
"lastname": "Pauls",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1206866"},
{
"firstname": "IA",
"lastname": "Pearsall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1133114"},
{
"firstname": "Terry",
"lastname": "Pearson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28615"},
{
"firstname": "Barbara",
"lastname": "Pelman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1510467"},
{
"firstname": "Tim",
"lastname": "Pelton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=22998"},
{
"firstname": "Briony",
"lastname": "Penn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=559088"},
{
"firstname": "Margaret",
"lastname": "Penning",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1375741"},
{
"firstname": "Ingrid",
"lastname": "Percy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=103988"},
{
"firstname": "Anna",
"lastname": "Peredo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=41087"},
{
"firstname": "Peter",
"lastname": "Perkins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=764534"},
{
"firstname": "Steve",
"lastname": "Perlman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1085261"},
{
"firstname": "Daniel",
"lastname": "Peters",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=699390"},
{
"firstname": "Melvin",
"lastname": "Peters",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1312431"},
{
"firstname": "Andrew",
"lastname": "Petter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=374143"},
{
"firstname": "Liz",
"lastname": "Philipose",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=30827"},
{
"firstname": "John",
"lastname": "Phillips",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29767"},
{
"firstname": "Rachel",
"lastname": "Phillips",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1667029"},
{
"firstname": "Michael",
"lastname": "Picard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=248497"},
{
"firstname": "Richard",
"lastname": "Pickard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=530597"},
{
"firstname": "Karen",
"lastname": "Pickett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1521850"},
{
"firstname": "Robin",
"lastname": "Pike",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1831526"},
{
"firstname": "Dennis",
"lastname": "Pilon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=934226"},
{
"firstname": "Craig",
"lastname": "Pinder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54712"},
{
"firstname": "Marc",
"lastname": "Pinkoski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57027"},
{
"firstname": "Andrew",
"lastname": "Pirie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=572042"},
{
"firstname": "James",
"lastname": "Plant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32604"},
{
"firstname": "Gayle",
"lastname": "Ployer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=802701"},
{
"firstname": "Elena",
"lastname": "Pnevmonidou",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=86339"},
{
"firstname": "Ron",
"lastname": "Podhorodeski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76065"},
{
"firstname": "Alexandra",
"lastname": "Dawkins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=464207"},
{
"firstname": "Annie",
"lastname": "Poirier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1275820"},
{
"firstname": "Matthew",
"lastname": "Pollard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54951"},
{
"firstname": "Dan",
"lastname": "Pollock",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1047626"},
{
"firstname": "Michael",
"lastname": "Pollock",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1960114"},
{
"firstname": "David",
"lastname": "Polson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=45617"},
{
"firstname": "Elissa",
"lastname": "Poole",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=638674"},
{
"firstname": "Natalee",
"lastname": "Popadiuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1846365"},
{
"firstname": "Naomi",
"lastname": "Pope",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=899298"},
{
"firstname": "Richard",
"lastname": "Porges",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=225779"},
{
"firstname": "Clara",
"lastname": "Portela",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1123037"},
{
"firstname": "Doug",
"lastname": "Porteous",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=705222"},
{
"firstname": "Pamela",
"lastname": "Porter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1149950"},
{
"firstname": "Maxim",
"lastname": "Pospelov",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=380799"},
{
"firstname": "Vera",
"lastname": "Pospelova",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=346158"},
{
"firstname": "Keith",
"lastname": "Potter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1066914"},
{
"firstname": "Karen",
"lastname": "Potts",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=755490"},
{
"firstname": "Gerald",
"lastname": "Poulton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29973"},
{
"firstname": "Cody",
"lastname": "Poulton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35755"},
{
"firstname": "Dolagobinda",
"lastname": "Pradhan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=640095"},
{
"firstname": "Jocelyne",
"lastname": "Praud",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1989458"},
{
"firstname": "Monica",
"lastname": "Prendergast",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=909970"},
{
"firstname": "Olga",
"lastname": "Pressitch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1636775"},
{
"firstname": "Brian",
"lastname": "Preston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1353770"},
{
"firstname": "Andrew",
"lastname": "Preston",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=251118"},
{
"firstname": "Jason",
"lastname": "Price",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1229340"},
{
"firstname": "John",
"lastname": "Price",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90739"},
{
"firstname": "Steve",
"lastname": "Price",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=342022"},
{
"firstname": "Scott",
"lastname": "Priestman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=715181"},
{
"firstname": "Michael",
"lastname": "Prince",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=97998"},
{
"firstname": "Christopher",
"lastname": "Pritchet",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90642"},
{
"firstname": "Denis",
"lastname": "Protti",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=204952"},
{
"firstname": "James",
"lastname": "Provan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76064"},
{
"firstname": "Terry",
"lastname": "Prowse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250544"},
{
"firstname": "Glen",
"lastname": "Pryhitka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1982329"},
{
"firstname": "Annette",
"lastname": "Przygoda",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1155905"},
{
"firstname": "Lucy",
"lastname": "Pullen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=387315"},
{
"firstname": "Ian",
"lastname": "Putnam",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92645"},
{
"firstname": "Anthony",
"lastname": "Quas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=984288"},
{
"firstname": "Pamela",
"lastname": "Quigg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1428622"},
{
"firstname": "Sheila",
"lastname": "Rabillard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=63733"},
{
"firstname": "Richard",
"lastname": "Rajala",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89704"},
{
"firstname": "Daler",
"lastname": "Rakhmatov",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=237585"},
{
"firstname": "Ramtin",
"lastname": "Rakhsha",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1937985"},
{
"firstname": "Narayana",
"lastname": "Ranganathan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1526324"},
{
"firstname": "Louis",
"lastname": "Ranger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=194650"},
{
"firstname": "Heather",
"lastname": "Ranson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=914455"},
{
"firstname": "Akshay",
"lastname": "Rathore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=821987"},
{
"firstname": "Bruce",
"lastname": "Ravelli",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1838378"},
{
"firstname": "Heather",
"lastname": "Raven",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=964027"},
{
"firstname": "Mike",
"lastname": "Raven",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1371261"},
{
"firstname": "Nick",
"lastname": "Raymond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1857191"},
{
"firstname": "Steven",
"lastname": "Rayner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=764897"},
{
"firstname": "Charlotte",
"lastname": "Reading",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1320349"},
{
"firstname": "Jeff",
"lastname": "Reading",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1881697"},
{
"firstname": "Reuben",
"lastname": "Redwood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1511678"},
{
"firstname": "Nancy",
"lastname": "Reed",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=904909"},
{
"firstname": "Christopher",
"lastname": "Reiche",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1368635"},
{
"firstname": "Thomas",
"lastname": "Reimchen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89618"},
{
"firstname": "Monica",
"lastname": "Reimer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=251080"},
{
"firstname": "Clive",
"lastname": "Reis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=109374"},
{
"firstname": "Dick",
"lastname": "Rennie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=698255"},
{
"firstname": "Bradford",
"lastname": "Rennie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1425820"},
{
"firstname": "Pablo",
"lastname": "Gautier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55058"},
{
"firstname": "Nick",
"lastname": "Reymond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1225625"},
{
"firstname": "Tim",
"lastname": "Richards",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=913755"},
{
"firstname": "Brian",
"lastname": "Richmond",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=407204"},
{
"firstname": "Matthew",
"lastname": "Riddett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1491701"},
{
"firstname": "Nozomi",
"lastname": "Riddington",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35754"},
{
"firstname": "Janet",
"lastname": "Riecken",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=634045"},
{
"firstname": "Kai",
"lastname": "Riecken",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1216480"},
{
"firstname": "Nola",
"lastname": "Ries",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=726402"},
{
"firstname": "Andrew",
"lastname": "Rippin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=87924"},
{
"firstname": "Adam",
"lastname": "Ritz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=853339"},
{
"firstname": "Benoit",
"lastname": "Rivard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250638"},
{
"firstname": "Sorin",
"lastname": "Rizeanu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1738207"},
{
"firstname": "Russell",
"lastname": "Robb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=123219"},
{
"firstname": "Lynda",
"lastname": "Robbins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1871978"},
{
"firstname": "Jillian",
"lastname": "Roberts",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=629813"},
{
"firstname": "Frank",
"lastname": "Roberts",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=50369"},
{
"firstname": "Stuart",
"lastname": "Robson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93818"},
{
"firstname": "Julia",
"lastname": "Rochtchina",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=215766"},
{
"firstname": "Carmen",
"lastname": "France",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1352683"},
{
"firstname": "Dominique",
"lastname": "Roelants",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54907"},
{
"firstname": "Peter",
"lastname": "Rogers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=938106"},
{
"firstname": "Nicholas",
"lastname": "Rolland",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=377305"},
{
"firstname": "Alex",
"lastname": "Rolland",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1038939"},
{
"firstname": "Luke",
"lastname": "Roman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=42930"},
{
"firstname": "Monica",
"lastname": "Roman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57643"},
{
"firstname": "Paul",
"lastname": "Romaniuk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92626"},
{
"firstname": "James",
"lastname": "Ronan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1535047"},
{
"firstname": "Daniel",
"lastname": "Rondeau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89955"},
{
"firstname": "Kara",
"lastname": "Ronellenfitch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1780083"},
{
"firstname": "J",
"lastname": "Roney",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89571"},
{
"firstname": "Rueben",
"lastname": "Redwood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1352684"},
{
"firstname": "Cindyann",
"lastname": "Redwood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1454296"},
{
"firstname": "Lisa",
"lastname": "Rosenberg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37589"},
{
"firstname": "Kathie",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1275206"},
{
"firstname": "Stephen",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40785"},
{
"firstname": "Mary",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=457336"},
{
"firstname": "Christopher",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1667699"},
{
"firstname": "Ian",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1422257"},
{
"firstname": "Elena",
"lastname": "Rossi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89355"},
{
"firstname": "Eric",
"lastname": "Roth",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29090"},
{
"firstname": "Abdul",
"lastname": "Roudsari",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1815584"},
{
"firstname": "Jessica",
"lastname": "Rourke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1349975"},
{
"firstname": "James",
"lastname": "Rowe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1188156"},
{
"firstname": "Gregory",
"lastname": "Rowe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76218"},
{
"firstname": "Arthur",
"lastname": "Rowe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=250433"},
{
"firstname": "Don",
"lastname": "Rowlatt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=47166"},
{
"firstname": "A",
"lastname": "Rowles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90007"},
{
"firstname": "Real",
"lastname": "Roy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=383077"},
{
"firstname": "Nilanjana",
"lastname": "Roy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52635"},
{
"firstname": "Patricia",
"lastname": "Roy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=48756"},
{
"firstname": "Jodie",
"lastname": "Royan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=636147"},
{
"firstname": "Jon",
"lastname": "Rudge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=908062"},
{
"firstname": "Denise",
"lastname": "Rudinicki",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1545843"},
{
"firstname": "Daromir",
"lastname": "Rudnyckyj",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=892206"},
{
"firstname": "Chiara",
"lastname": "Ruffa",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1252947"},
{
"firstname": "Marsha",
"lastname": "Runtz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=449448"},
{
"firstname": "Frank",
"lastname": "Ruskey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36619"},
{
"firstname": "Dan",
"lastname": "Russek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=471236"},
{
"firstname": "Malcolm",
"lastname": "Rutherford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=69512"},
{
"firstname": "Patrick",
"lastname": "Rysiew",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=966934"},
{
"firstname": "Rabih",
"lastname": "Saab",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1391227"},
{
"firstname": "Robert",
"lastname": "Sacci",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=974432"},
{
"firstname": "Kirsten",
"lastname": "Yekta",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1989122"},
{
"firstname": "Eric",
"lastname": "Sager",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=78827"},
{
"firstname": "Pahi",
"lastname": "Saikia",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1473998"},
{
"firstname": "Sushil",
"lastname": "Saini",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=764824"},
{
"firstname": "Hayato",
"lastname": "Sakamoto",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1908417"},
{
"firstname": "Andrea",
"lastname": "Sakar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1552005"},
{
"firstname": "Sonia",
"lastname": "Salkeld",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1026342"},
{
"firstname": "Alana",
"lastname": "Samson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=878028"},
{
"firstname": "Calvin",
"lastname": "Sandborn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=494646"},
{
"firstname": "Gurmit",
"lastname": "Sandhu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=132701"},
{
"firstname": "Kathy",
"lastname": "Sanford",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=72769"},
{
"firstname": "Neralagatta",
"lastname": "Sangeetha",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1267522"},
{
"firstname": "Harb",
"lastname": "Sanghara",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54752"},
{
"firstname": "Harbindar",
"lastname": "",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1932340"},
{
"firstname": "Nadia",
"lastname": "Sangster",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=424408"},
{
"firstname": "Esther",
"lastname": "Gormley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1111261"},
{
"firstname": "Mary",
"lastname": "Sanseverino",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43594"},
{
"firstname": "Ana",
"lastname": "Santos",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1659290"},
{
"firstname": "Yudi",
"lastname": "Santoso",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1634715"},
{
"firstname": "Louis",
"lastname": "Demers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1564833"},
{
"firstname": "Lawrence",
"lastname": "Saunders",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1661948"},
{
"firstname": "Thomas",
"lastname": "Saunders",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32190"},
{
"firstname": "Leslie",
"lastname": "Saxon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=64358"},
{
"firstname": "Jentery",
"lastname": "Sayers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1615401"},
{
"firstname": "Margaret",
"lastname": "Scaia",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=454188"},
{
"firstname": "Leila",
"lastname": "Scannell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1726704"},
{
"firstname": "Brian",
"lastname": "Scarfe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=219143"},
{
"firstname": "Colin",
"lastname": "Scarfe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=57136"},
{
"firstname": "Siobhan",
"lastname": "Scarry",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669487"},
{
"firstname": "Joseph",
"lastname": "Schaafsma",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=113289"},
{
"firstname": "Valentin",
"lastname": "Schaefer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=962236"},
{
"firstname": "Saryta",
"lastname": "Schaerer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=98998"},
{
"firstname": "Karen",
"lastname": "Schafer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=85694"},
{
"firstname": "Charlotte",
"lastname": "Schallie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1659128"},
{
"firstname": "Andrew",
"lastname": "Schloss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37810"},
{
"firstname": "Alexander",
"lastname": "Schmid",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=599833"},
{
"firstname": "Jeremy",
"lastname": "Schmidt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1050929"},
{
"firstname": "Louise",
"lastname": "Schmidt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=225585"},
{
"firstname": "Oliver",
"lastname": "Schmidtke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39444"},
{
"firstname": "Rita",
"lastname": "Schreiber",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=225539"},
{
"firstname": "Herbert",
"lastname": "Schuetze",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28641"},
{
"firstname": "Ulf",
"lastname": "Schuetze",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1119562"},
{
"firstname": "Robert",
"lastname": "Schuler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=81004"},
{
"firstname": "Mark",
"lastname": "Schurch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=604069"},
{
"firstname": "Paul",
"lastname": "Schure",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70468"},
{
"firstname": "Robin",
"lastname": "Scobie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=99672"},
{
"firstname": "Steven",
"lastname": "Scobie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32845"},
{
"firstname": "David",
"lastname": "Scoones",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54307"},
{
"firstname": "Samantha",
"lastname": "Scott",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1177484"},
{
"firstname": "David",
"lastname": "Scott",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39496"},
{
"firstname": "Stefan",
"lastname": "Scott",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=472759"},
{
"firstname": "Rick",
"lastname": "Searle",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=219167"},
{
"firstname": "Mani",
"lastname": "Sehgal",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1186742"},
{
"firstname": "Jane",
"lastname": "Sellwood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1032386"},
{
"firstname": "Kristin",
"lastname": "Semmens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=580377"},
{
"firstname": "Justine",
"lastname": "Semmens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1721337"},
{
"firstname": "Phyllis",
"lastname": "Senese",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92713"},
{
"firstname": "Micaela",
"lastname": "Serra",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=10605"},
{
"firstname": "Norma",
"lastname": "Sogas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1825634"},
{
"firstname": "Omid",
"lastname": "Shabestari",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1650897"},
{
"firstname": "Kara",
"lastname": "Shaw",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=269261"},
{
"firstname": "Robert",
"lastname": "Sheffield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=217962"},
{
"firstname": "Yan",
"lastname": "Shen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1659147"},
{
"firstname": "Tracy",
"lastname": "Shenton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1815157"},
{
"firstname": "Danielle",
"lastname": "Shepherd",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55059"},
{
"firstname": "Janice",
"lastname": "Shewey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1291332"},
{
"firstname": "Linda",
"lastname": "Shi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1324006"},
{
"firstname": "Yang",
"lastname": "Shi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1464567"},
{
"firstname": "Lincoln",
"lastname": "Shlensky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=938385"},
{
"firstname": "Jillian",
"lastname": "Shoichet",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669538"},
{
"firstname": "Ali",
"lastname": "Shoja",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=257018"},
{
"firstname": "Brian",
"lastname": "Shorter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1480808"},
{
"firstname": "Gordon",
"lastname": "Shrimpton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54950"},
{
"firstname": "Regan",
"lastname": "Shrumm",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1933553"},
{
"firstname": "Zhisheng",
"lastname": "Shuai",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1628090"},
{
"firstname": "Nicole",
"lastname": "Shukin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1159279"},
{
"firstname": "Leslie",
"lastname": "Shumka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37991"},
{
"firstname": "Leah",
"lastname": "Shumka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1861350"},
{
"firstname": "Paul",
"lastname": "Shure",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1269197"},
{
"firstname": "Melanie",
"lastname": "Siebert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=889561"},
{
"firstname": "Jason",
"lastname": "Siefken",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1860771"},
{
"firstname": "Lynne",
"lastname": "Siemens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=924184"},
{
"firstname": "Raymond",
"lastname": "Siemens",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=728566"},
{
"firstname": "Danika",
"lastname": "Sihota",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1624367"},
{
"firstname": "Thiago",
"lastname": "Silva",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=636307"},
{
"firstname": "Sheila",
"lastname": "Sim",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=419205"},
{
"firstname": "Mihai",
"lastname": "Sima",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330454"},
{
"firstname": "Jill",
"lastname": "Simmons",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=80870"},
{
"firstname": "Martin",
"lastname": "Simmons",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=540890"},
{
"firstname": "Aislinn",
"lastname": "Sirk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1423005"},
{
"firstname": "Georgia",
"lastname": "Sitara",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89327"},
{
"firstname": "David",
"lastname": "Skal",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1030034"},
{
"firstname": "Ronald",
"lastname": "Skelton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=40468"},
{
"firstname": "Jim",
"lastname": "Skinner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=868083"},
{
"firstname": "Colette",
"lastname": "Smart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1576433"},
{
"firstname": "Brock",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54607"},
{
"firstname": "Claudia",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=88872"},
{
"firstname": "Tim",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=847706"},
{
"firstname": "Helen",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55897"},
{
"firstname": "Ron",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=512779"},
{
"firstname": "Monika",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=112068"},
{
"firstname": "Antonia",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=944220"},
{
"firstname": "Daniel",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=218363"},
{
"firstname": "Keith",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89638"},
{
"firstname": "Paul",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91644"},
{
"firstname": "Gordon",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330227"},
{
"firstname": "Martin",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29810"},
{
"firstname": "Andre",
"lastname": "Smith",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=888081"},
{
"firstname": "Suzanne",
"lastname": "Snizek",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1920161"},
{
"firstname": "Poman",
"lastname": "So",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54866"},
{
"firstname": "Eva",
"lastname": "Kinderman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=843246"},
{
"firstname": "Jim",
"lastname": "Soles",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1599514"},
{
"firstname": "Zhiying",
"lastname": "Song",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1971581"},
{
"firstname": "Madeline",
"lastname": "Sonik",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1780820"},
{
"firstname": "Terry",
"lastname": "Soo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1502061"},
{
"firstname": "Amy",
"lastname": "Sopinka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1165790"},
{
"firstname": "Reinel",
"lastname": "Alfonso",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1464524"},
{
"firstname": "Alina",
"lastname": "Sotskova",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1830738"},
{
"firstname": "Ahmed",
"lastname": "Sourour",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=81150"},
{
"firstname": "Nancy",
"lastname": "South",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=254556"},
{
"firstname": "Fred",
"lastname": "Speckeen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1747927"},
{
"firstname": "Kimberly",
"lastname": "Speers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1517811"},
{
"firstname": "Paul",
"lastname": "Spence",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=840692"},
{
"firstname": "Emily",
"lastname": "Spencer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1143112"},
{
"firstname": "Anne",
"lastname": "Spilker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1155652"},
{
"firstname": "Simon",
"lastname": "Springer",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1802452"},
{
"firstname": "Carina",
"lastname": "Sprungk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=897049"},
{
"firstname": "Venkatesh",
"lastname": "Srinivasan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=539283"},
{
"firstname": "Gautam",
"lastname": "Srivastava",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=735576"},
{
"firstname": "Rekha",
"lastname": "Srivastava",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=22994"},
{
"firstname": "Hari",
"lastname": "Srivastava",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92649"},
{
"firstname": "Christine",
"lastname": "Peter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=149536"},
{
"firstname": "Ann",
"lastname": "Stahl",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1271759"},
{
"firstname": "Peter",
"lastname": "Stahl",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1950991"},
{
"firstname": "Jordan",
"lastname": "Ross",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=779022"},
{
"firstname": "Erin",
"lastname": "Star",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1509505"},
{
"firstname": "Heidi",
"lastname": "Stark",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1802212"},
{
"firstname": "Brian",
"lastname": "Starzomski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1658231"},
{
"firstname": "Robert",
"lastname": "Steacy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39675"},
{
"firstname": "Carrie",
"lastname": "Steckler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1250548"},
{
"firstname": "Geoffrey",
"lastname": "Steeves",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=389574"},
{
"firstname": "Shirley",
"lastname": "Stefanson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1375817"},
{
"firstname": "Ulrike",
"lastname": "Stege",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=80617"},
{
"firstname": "Peter",
"lastname": "Stephenson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=34184"},
{
"firstname": "Marla",
"lastname": "Stevenson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=952496"},
{
"firstname": "Ken",
"lastname": "Stewart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54976"},
{
"firstname": "Kenneth",
"lastname": "Stewart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1898164"},
{
"firstname": "Rosa",
"lastname": "Stewart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75208"},
{
"firstname": "Melanie",
"lastname": "Millar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=926006"},
{
"firstname": "Allan",
"lastname": "Stichbury",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=97430"},
{
"firstname": "Jennifer",
"lastname": "Stillwell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1680000"},
{
"firstname": "Danu",
"lastname": "Stinson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1499711"},
{
"firstname": "Mark",
"lastname": "Stoddart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1272343"},
{
"firstname": "Jo",
"lastname": "Stoltz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=431297"},
{
"firstname": "Margaret",
"lastname": "Storey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1632382"},
{
"firstname": "Karla",
"lastname": "Stout",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=570622"},
{
"firstname": "Esther",
"lastname": "Strauss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=126767"},
{
"firstname": "Susan",
"lastname": "Strega",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1109323"},
{
"firstname": "Henning",
"lastname": "Struchtrup",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76060"},
{
"firstname": "Nicolae",
"lastname": "Strungaru",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=941383"},
{
"firstname": "Lynneth",
"lastname": "Hill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1299121"},
{
"firstname": "Peter",
"lastname": "Such",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89765"},
{
"firstname": "Chan",
"lastname": "Suh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1245529"},
{
"firstname": "Afzal",
"lastname": "Suleman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76061"},
{
"firstname": "Lauren",
"lastname": "Sulz",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1510083"},
{
"firstname": "Ying",
"lastname": "Sun",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=367571"},
{
"firstname": "Lisa",
"lastname": "Surridge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27047"},
{
"firstname": "Reuven",
"lastname": "Sussman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1751430"},
{
"firstname": "Cheryl",
"lastname": "Suzack",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=765524"},
{
"firstname": "Jacobus",
"lastname": "Swarts",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=331686"},
{
"firstname": "Megan",
"lastname": "Swift",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=513098"},
{
"firstname": "Rodney",
"lastname": "Symington",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=601465"},
{
"firstname": "Moira",
"lastname": "Szabo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92251"},
{
"firstname": "Mike",
"lastname": "Szymanski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1946135"},
{
"firstname": "Michal",
"lastname": "",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951725"},
{
"firstname": "Rumiko",
"lastname": "Tachibana",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1201839"},
{
"firstname": "Glen",
"lastname": "Tadsen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=426354"},
{
"firstname": "Marie",
"lastname": "Taggart",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39498"},
{
"firstname": "Proma",
"lastname": "Tagore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=43754"},
{
"firstname": "Yoko",
"lastname": "Takashima",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1452403"},
{
"firstname": "James",
"lastname": "Tanaka",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=226232"},
{
"firstname": "Karen",
"lastname": "Tang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28542"},
{
"firstname": "Heather",
"lastname": "Tapley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1174819"},
{
"firstname": "Doug",
"lastname": "Tate",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28795"},
{
"firstname": "Jeremy",
"lastname": "Tatum",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=331184"},
{
"firstname": "Cici",
"lastname": "Tavares",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1833614"},
{
"firstname": "Steve",
"lastname": "Tax",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55305"},
{
"firstname": "Stephen",
"lastname": "Tax",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1475176"},
{
"firstname": "John",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=383080"},
{
"firstname": "Doug",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=55066"},
{
"firstname": "Nichole",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1471673"},
{
"firstname": "Alan",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1836488"},
{
"firstname": "Duncan",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=94202"},
{
"firstname": "Roberta",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=222847"},
{
"firstname": "Angus",
"lastname": "Taylor",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75603"},
{
"firstname": "Lindsay",
"lastname": "Tedds",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1104845"},
{
"firstname": "Paul",
"lastname": "Teel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1476564"},
{
"firstname": "Kathy",
"lastname": "Teghtsoonian",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=948101"},
{
"firstname": "Shelby",
"lastname": "Temple",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=853947"},
{
"firstname": "Brad",
"lastname": "Temple",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=863201"},
{
"firstname": "Megan",
"lastname": "Terepocki",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1141722"},
{
"firstname": "Laura",
"lastname": "Teshima",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1772957"},
{
"firstname": "Chris",
"lastname": "Teuton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1501017"},
{
"firstname": "Christopher",
"lastname": "Teuton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1503938"},
{
"firstname": "Susan",
"lastname": "Thackeray",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1680762"},
{
"firstname": "David",
"lastname": "Thatcher",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54881"},
{
"firstname": "Wayne",
"lastname": "Thirsk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1278535"},
{
"firstname": "Ilamparithi",
"lastname": "Chelvan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1363247"},
{
"firstname": "Brian",
"lastname": "Thom",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1618585"},
{
"firstname": "Chris",
"lastname": "Thomas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=113737"},
{
"firstname": "Dave",
"lastname": "Thomas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=914838"},
{
"firstname": "I",
"lastname": "Thomo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=472844"},
{
"firstname": "Kika",
"lastname": "Thorne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=934522"},
{
"firstname": "Ken",
"lastname": "Thornicroft",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54617"},
{
"firstname": "Ian",
"lastname": "Thornton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=93117"},
{
"firstname": "Frances",
"lastname": "Thorsen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=514623"},
{
"firstname": "Helga",
"lastname": "Thorson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1260405"},
{
"firstname": "John",
"lastname": "Threlfall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1288773"},
{
"firstname": "Jun",
"lastname": "Tian",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1234372"},
{
"firstname": "Charles",
"lastname": "Tidler",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=63365"},
{
"firstname": "Bernie",
"lastname": "Till",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=645489"},
{
"firstname": "Frances",
"lastname": "Timbers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1721334"},
{
"firstname": "Chris",
"lastname": "Tippett",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1505982"},
{
"firstname": "Ruthanne",
"lastname": "Tobin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1181994"},
{
"firstname": "Thea",
"lastname": "Todd",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=898749"},
{
"firstname": "Honorino",
"lastname": "Todino",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1556445"},
{
"firstname": "Chris",
"lastname": "Tollefson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=478043"},
{
"firstname": "Diane",
"lastname": "Tolomeo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=69507"},
{
"firstname": "Lara",
"lastname": "Tomaszewska",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506640"},
{
"firstname": "Ryan",
"lastname": "Tonkin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1414427"},
{
"firstname": "Randel",
"lastname": "Tonks",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1461192"},
{
"firstname": "Melanie",
"lastname": "Tory",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=968691"},
{
"firstname": "Kathleen",
"lastname": "Towne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=802703"},
{
"firstname": "Norah",
"lastname": "Trace",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=909870"},
{
"firstname": "Matt",
"lastname": "Trahan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1865188"},
{
"firstname": "Andrew",
"lastname": "Trant",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1992973"},
{
"firstname": "Issa",
"lastname": "Traore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=205994"},
{
"firstname": "Tim",
"lastname": "Travers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=573143"},
{
"firstname": "Annemarie",
"lastname": "Travers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1540801"},
{
"firstname": "Grant",
"lastname": "Treloar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1505980"},
{
"firstname": "Crystal",
"lastname": "Tremblay",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1536058"},
{
"firstname": "Mak",
"lastname": "Trifkovic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=924605"},
{
"firstname": "Travis",
"lastname": "Trudeau",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=951364"},
{
"firstname": "Viet",
"lastname": "Luu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=864453"},
{
"firstname": "Amy",
"lastname": "Tsai",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1042992"},
{
"firstname": "Min",
"lastname": "Tsao",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=332301"},
{
"firstname": "Michael",
"lastname": "Tsosie",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89809"},
{
"firstname": "John",
"lastname": "Tucker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29023"},
{
"firstname": "Holly",
"lastname": "Tukko",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1968070"},
{
"firstname": "Stanton",
"lastname": "Tuller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=79992"},
{
"firstname": "James",
"lastname": "Tully",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=325887"},
{
"firstname": "Elizabeth",
"lastname": "Tumasonis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1293643"},
{
"firstname": "Verena",
"lastname": "Tunnicliffe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89574"},
{
"firstname": "Amanda",
"lastname": "Turner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1950802"},
{
"firstname": "Nancy",
"lastname": "Turner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65297"},
{
"firstname": "Susan",
"lastname": "Turner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56625"},
{
"firstname": "David",
"lastname": "Turner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32445"},
{
"firstname": "Derek",
"lastname": "Turton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54878"},
{
"firstname": "George",
"lastname": "Tzanetakis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=427878"},
{
"firstname": "Alicia",
"lastname": "Ulysses",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54600"},
{
"firstname": "Christopher",
"lastname": "Upton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=86337"},
{
"firstname": "Chad",
"lastname": "Uran",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1678980"},
{
"firstname": "Suzanne",
"lastname": "Urbanczyk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1616328"},
{
"firstname": "Suzanne",
"lastname": "Urbanzyk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=74752"},
{
"firstname": "Marilyn",
"lastname": "Uy",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1324007"},
{
"firstname": "Peyman",
"lastname": "Vahabzadeh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=545484"},
{
"firstname": "Thea",
"lastname": "Vakil",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89825"},
{
"firstname": "Lidio",
"lastname": "Valdez",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=520979"},
{
"firstname": "Mike",
"lastname": "Valente",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1034274"},
{
"firstname": "Bill",
"lastname": "Valgardson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=31643"},
{
"firstname": "Christian",
"lastname": "Buskirk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1917146"},
{
"firstname": "Stephanie",
"lastname": "Citters",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1026565"},
{
"firstname": "Paul",
"lastname": "Bates",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1879020"},
{
"firstname": "Eileen",
"lastname": "Keller",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=391753"},
{
"firstname": "Gib",
"lastname": "Ert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1803628"},
{
"firstname": "Geri",
"lastname": "Gyn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=685795"},
{
"firstname": "Cornelis",
"lastname": "Kooten",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92041"},
{
"firstname": "M",
"lastname": "Luven",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91033"},
{
"firstname": "Alex",
"lastname": "Netten",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70981"},
{
"firstname": "Richard",
"lastname": "Oort",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107858"},
{
"firstname": "Frank",
"lastname": "Veggel",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=333801"},
{
"firstname": "Don",
"lastname": "Vandenburg",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=304685"},
{
"firstname": "Phillip",
"lastname": "Vannini",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=365061"},
{
"firstname": "Diana",
"lastname": "Varela",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=600027"},
{
"firstname": "Stephanie",
"lastname": "Varga",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1462263"},
{
"firstname": "Brian",
"lastname": "Vatne",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1397539"},
{
"firstname": "Marie",
"lastname": "Vautier",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=52212"},
{
"firstname": "Kim",
"lastname": "Venn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=793368"},
{
"firstname": "Amy",
"lastname": "Verdun",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90091"},
{
"firstname": "Bogdan",
"lastname": "Verjinschi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=75463"},
{
"firstname": "Elizabeth",
"lastname": "Vibert",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=80869"},
{
"firstname": "Geoffrey",
"lastname": "Vickers",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76062"},
{
"firstname": "Anthony",
"lastname": "Vickery",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89228"},
{
"firstname": "Liana",
"lastname": "Victorino",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1559501"},
{
"firstname": "Daniel",
"lastname": "Vo",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1271507"},
{
"firstname": "John",
"lastname": "Volpe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=506850"},
{
"firstname": "Patrick",
"lastname": "Aderkas",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=90038"},
{
"firstname": "Graham",
"lastname": "Voss",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=39168"},
{
"firstname": "Kristine",
"lastname": "Votova",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1470249"},
{
"firstname": "Ned",
"lastname": "Vukovic",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=634798"},
{
"firstname": "Bill",
"lastname": "Wadge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=48636"},
{
"firstname": "Christine",
"lastname": "Wadge",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=36622"},
{
"firstname": "Mary",
"lastname": "Wagner",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=844141"},
{
"firstname": "Judy",
"lastname": "Wahn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=28990"},
{
"firstname": "Michael",
"lastname": "Waite",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1167303"},
{
"firstname": "Phil",
"lastname": "Wakefield",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38164"},
{
"firstname": "Kevin",
"lastname": "Walby",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1620284"},
{
"firstname": "Ian",
"lastname": "Walker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=32227"},
{
"firstname": "Rob",
"lastname": "Walker",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=238556"},
{
"firstname": "Erika",
"lastname": "Wall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1982326"},
{
"firstname": "Marty",
"lastname": "Wall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=890817"},
{
"firstname": "Andrea",
"lastname": "Walsh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=70007"},
{
"firstname": "John",
"lastname": "Walsh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1439802"},
{
"firstname": "Jill",
"lastname": "Walshaw",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1305350"},
{
"firstname": "Patrick",
"lastname": "Walter",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=107116"},
{
"firstname": "Christine",
"lastname": "Walterhouse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95373"},
{
"firstname": "Peter",
"lastname": "Wan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=34982"},
{
"firstname": "Ning",
"lastname": "Wang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=963605"},
{
"firstname": "Margaret",
"lastname": "Warbey",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=65397"},
{
"firstname": "Claire",
"lastname": "Ward",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=361230"},
{
"firstname": "Valerie",
"lastname": "Warder",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1425706"},
{
"firstname": "Christopher",
"lastname": "Warren",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1727509"},
{
"firstname": "Scott",
"lastname": "Watson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=926001"},
{
"firstname": "Philip",
"lastname": "Watt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=568170"},
{
"firstname": "Beth",
"lastname": "Watton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1004388"},
{
"firstname": "Arthur",
"lastname": "Watton",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=87977"},
{
"firstname": "Andrew",
"lastname": "Weaver",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=217667"},
{
"firstname": "Barry",
"lastname": "Weaver",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=958522"},
{
"firstname": "Michael",
"lastname": "Webb",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38367"},
{
"firstname": "Jeremy",
"lastname": "Webber",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=835359"},
{
"firstname": "Jens",
"lastname": "Weber",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=938112"},
{
"firstname": "Elizabeth",
"lastname": "Webster",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1678292"},
{
"firstname": "Sarah",
"lastname": "Weibe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1890740"},
{
"firstname": "Gerlinde",
"lastname": "Stuckmann",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=634874"},
{
"firstname": "Anthony",
"lastname": "Welch",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=804073"},
{
"firstname": "Linda",
"lastname": "Welling",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=347013"},
{
"firstname": "Christine",
"lastname": "Welsh",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=149537"},
{
"firstname": "Andrew",
"lastname": "Wender",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=110987"},
{
"firstname": "Howard",
"lastname": "Wenger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=77709"},
{
"firstname": "David",
"lastname": "Western",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1015066"},
{
"firstname": "Rachel",
"lastname": "Westfall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=352123"},
{
"firstname": "Charmaine",
"lastname": "Wetherell",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1773000"},
{
"firstname": "Weyadon",
"lastname": "Weyadon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1200762"},
{
"firstname": "Joan",
"lastname": "Higgins",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=95681"},
{
"firstname": "Adrienne",
"lastname": "White",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1554695"},
{
"firstname": "Jennifer",
"lastname": "White",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=854974"},
{
"firstname": "Janet",
"lastname": "White",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1806980"},
{
"firstname": "Geoff",
"lastname": "Whitehall",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=35578"},
{
"firstname": "Michael",
"lastname": "Whiticar",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1036814"},
{
"firstname": "Barbara",
"lastname": "Whittington",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27875"},
{
"firstname": "Beatrixe",
"lastname": "Whittome",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1481162"},
{
"firstname": "Wendy",
"lastname": "Wickwire",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89674"},
{
"firstname": "Michelle",
"lastname": "Wiebe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1156444"},
{
"firstname": "Sarah",
"lastname": "Wiebe",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1904081"},
{
"firstname": "Rebecca",
"lastname": "Wigen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92614"},
{
"firstname": "Rhordon",
"lastname": "Wikkramatileke",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=767475"},
{
"firstname": "Joshua",
"lastname": "Wilburn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1616471"},
{
"firstname": "Peter",
"lastname": "Wild",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=860142"},
{
"firstname": "Sarah",
"lastname": "Wilkinson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1950941"},
{
"firstname": "Dan",
"lastname": "Wilkinson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1469455"},
{
"firstname": "Frederick",
"lastname": "Willeboordse",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1002490"},
{
"firstname": "Trevor",
"lastname": "Williams",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29020"},
{
"firstname": "Peter",
"lastname": "Williams",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1669027"},
{
"firstname": "Adrienne",
"lastname": "Boyarin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=963026"},
{
"firstname": "Peter",
"lastname": "Williamson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1673356"},
{
"firstname": "Jon",
"lastname": "Willis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=837509"},
{
"firstname": "Fonda",
"lastname": "Willis",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1451932"},
{
"firstname": "Christopher",
"lastname": "Willmore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1181942"},
{
"firstname": "Chris",
"lastname": "Wilmore",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1005961"},
{
"firstname": "Mike",
"lastname": "Wilmut",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56628"},
{
"firstname": "Susan",
"lastname": "Wilson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=488873"},
{
"firstname": "Alf",
"lastname": "Wilson",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1506479"},
{
"firstname": "Neville",
"lastname": "Winchester",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=224674"},
{
"firstname": "Monika",
"lastname": "Winn",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54609"},
{
"firstname": "Adriana",
"lastname": "Wise",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=62252"},
{
"firstname": "Jennifer",
"lastname": "Wise",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89369"},
{
"firstname": "Bob",
"lastname": "Wise",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=902867"},
{
"firstname": "Les",
"lastname": "Wiseman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1375140"},
{
"firstname": "Jane",
"lastname": "Wodlinger",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1888944"},
{
"firstname": "Roger",
"lastname": "Wolff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=175722"},
{
"firstname": "Lynneth",
"lastname": "Wolski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89539"},
{
"firstname": "Samuel",
"lastname": "Wong",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=293526"},
{
"firstname": "Paul",
"lastname": "Wood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=29117"},
{
"firstname": "Jim",
"lastname": "Wood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1433429"},
{
"firstname": "Donna",
"lastname": "Wood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=884855"},
{
"firstname": "Jan",
"lastname": "Wood",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89226"},
{
"firstname": "Scott",
"lastname": "Woodcock",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=99591"},
{
"firstname": "Erica",
"lastname": "Woodin",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1061544"},
{
"firstname": "Lawrence",
"lastname": "Woods",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1033746"},
{
"firstname": "Wesley",
"lastname": "Wooley",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89445"},
{
"firstname": "Yuen",
"lastname": "Woon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89187"},
{
"firstname": "Marion",
"lastname": "Wright",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1107945"},
{
"firstname": "Ron",
"lastname": "Wright",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1795269"},
{
"firstname": "Astri",
"lastname": "Wright",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=76557"},
{
"firstname": "Guoguang",
"lastname": "Wu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=487418"},
{
"firstname": "Kui",
"lastname": "Wu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=56571"},
{
"firstname": "Zheng",
"lastname": "Wu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=330237"},
{
"firstname": "Jeremy",
"lastname": "Wulff",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1146750"},
{
"firstname": "Victoria",
"lastname": "Wyatt",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=516365"},
{
"firstname": "Margaret",
"lastname": "Wyeth",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=38578"},
{
"firstname": "Brian",
"lastname": "Wyvill",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=965744"},
{
"firstname": "Ming",
"lastname": "Xiang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1436810"},
{
"firstname": "Jing",
"lastname": "Xu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1151045"},
{
"firstname": "Feng",
"lastname": "Xu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=459162"},
{
"firstname": "Adam",
"lastname": "Yaghi",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1886417"},
{
"firstname": "Hong",
"lastname": "Yang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=598509"},
{
"firstname": "Stephenson",
"lastname": "Yang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=87982"},
{
"firstname": "Audrey",
"lastname": "Yap",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=919226"},
{
"firstname": "Jaime",
"lastname": "Yard",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1806226"},
{
"firstname": "Julian",
"lastname": "Yates",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1331510"},
{
"firstname": "Erdem",
"lastname": "Yazganoglu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1119285"},
{
"firstname": "Jane",
"lastname": "Ye",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=46578"},
{
"firstname": "Serhy",
"lastname": "Yekelchyk",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=88717"},
{
"firstname": "kuo",
"lastname": "Yenkuang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1951501"},
{
"firstname": "Jin",
"lastname": "Yoon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=414766"},
{
"firstname": "Tae",
"lastname": "Yoon",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1058913"},
{
"firstname": "Robert",
"lastname": "Youds",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=172595"},
{
"firstname": "Kailyn",
"lastname": "Young",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1568411"},
{
"firstname": "Susan",
"lastname": "Young",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=91671"},
{
"firstname": "James",
"lastname": "Young",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=92188"},
{
"firstname": "Louis",
"lastname": "Yu",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1370007"},
{
"firstname": "Xiaoming",
"lastname": "Yuan",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=785730"},
{
"firstname": "Karen",
"lastname": "Yuen",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1493136"},
{
"firstname": "Robert",
"lastname": "Yuncken",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1108872"},
{
"firstname": "Laura",
"lastname": "Zadnik",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1306890"},
{
"firstname": "Michael",
"lastname": "Zastre",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=27464"},
{
"firstname": "Paul",
"lastname": "Zehr",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=225624"},
{
"firstname": "Hao",
"lastname": "Zhang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=54622"},
{
"firstname": "Lijun",
"lastname": "Zhang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1841287"},
{
"firstname": "LI",
"lastname": "Zhou",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1794668"},
{
"firstname": "Julie",
"lastname": "Zhou",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=232831"},
{
"firstname": "Min",
"lastname": "Zhou",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1674251"},
{
"firstname": "Yanyan",
"lastname": "Zhuang",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=1680089"},
{
"firstname": "Achilles",
"lastname": "Ziakris",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=899569"},
{
"firstname": "Adam",
"lastname": "Zielinski",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37414"},
{
"firstname": "David",
"lastname": "Zimmerman",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=37985"},
{
"firstname": "Doug",
"lastname": "Zook",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=645466"},
{
"firstname": "Jan",
"lastname": "Zwicky",
"url": "http://www.ratemyprofessors.com/ShowRatings.jsp?tid=89312"},
];


function profFinder() {
	   var button = $("<button id ='btn'>Hover for info: </button>");
        
        subArr = [];
        $(".datadisplaytable.tablesorter tr").each(function (index) {
            $cells = $(this).find("td");
            
                                                         //background script pushes professor names to local storage

            $cells.each(function (cellIndex) {          //search column to find the professor name one
                
                if (cellIndex == 19) {                          //once found send message to background script
                                                                //background script pushes professor names to local storage
                	var name = $(this).text();                     //popup reads local storage to
                    var result = $.grep(myArray, function(e){ return name.includes(e.firstname) && name.includes(e.lastname); }); //contains object of professor
                        

                    
                    if(name.includes("TBA") || subArr.indexOf(name)>-1 ||result.length==0){
                           // console.log("tba or already found");
                    }else{
                       							var hasAppended = false;
                       							$(this).wrap(button);
						                       	var moveLeft = 20;
						                       	var moveDown = 10;
						        

						         $(this).hover(
						                        		function(e){ //onhover
						                               		
						                        			
							                       	        console.log(result[0].url);              	
							                            	if(hasAppended == false){

							                            		for(var each =0;each<result.length;each++){
							                                    	
							                                    	//ajax(myCallBack, result[each],each); //now have prof info use fact that to onclick you must onhover
							                                  		chrome.runtime.sendMessage({teach: result[each],each: each},function(response){
							                                  			
							                    						myCallBack(response);
							                                  			//myCallBack(response.infos,response.teachObj,repsonse.each);

							                                  		});
							                                  		hasAppended = true;
							                                  		
							                             			     	
							                          	

							                           			} //end for
							                           			
							                                  		
							                           				
							                           		} else {
							                           			
							                           			var butSelector = $("button td.dddefault:contains('"+ name +"')").parent();
							                           			var popupSelector = butSelector.parent().next();
							                           			
							                           			
							                           			$(popupSelector).show().css('top',e.pageY +moveDown)
							                           				.css('left',e.pageX+ moveLeft);
							                           						
							                           			$('div#pop-up2:eq(0)').show().css('top',e.pageY +moveDown)
							                           				.css('left',e.pageX+ moveLeft);
							                           			
							                           			}//end else

							                           
							                     //end onhover       	
						                        },  	function(){ //offhover
						                        			$('div#pop-up').hide();
						                        			$('div#pop-up2').hide();
						                       			 }); //end off hover
						                       
						                     $(this).mousemove(function(e){
						                     	$("div#pop-up").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft+20);
						                     	$("div#pop-up2").css('top', e.pageY + moveDown).css('left', e.pageX + moveLeft-150);

						                     });

						                     $(this).click(function(){
						                     		for (var i = 0 ; i <result.length; i++) {
						                    	 		window.open(result[i].url)
						                	     	};
						                
						                     });
						                        

						subArr.push(name);
                        console.log("button appended to " + name);   
                        console.log(subArr);
                    }
                        
                
              

                };


           


            });

        });
        




    chrome.extension.sendMessage({professors: subArr}); //pushes list of professors to Localstorage for use in popup HTML



 


}




/*function ajax(callback, array,each){ // ajax to obtain data from url
    try{
        $.get(array.url, function(data){
                var $response = $(data);
                callback($response,array,each);

        });
    }catch(err){
        console.log(err);

    }
    
}
*/




//function myCallBack($response, array,each){ //function that relies on returned ratings
  function myCallBack(response){
    var each = response.each;
    var array = response.teachObj;
    var $response = response.infos;
    
   
    var total = "/5.0";
    overallRating = $($response).find("div.grade").eq(0).text() + total;
    avgGrade = $($response).find('div.grade').eq(1).text();

    helpfulness = $($response).find('div.rating').eq(0).text()+ total;
    clarity = $($response).find('div.rating').eq(1).text()+ total;
    easiness = $($response).find('div.rating').eq(2).text()+ total;
    
    numRatings = $($response).find("div.table-toggle.rating-count.active").eq(0).text();
    //numRatings =  numRatings.slice(0,11) + " Ratings"
    //hot = chrome.extension.getURL("scorching-chili.png");
    console.log(overallRating);

    var nameSelector = $("") 
    var butSelector = $("button td.dddefault:contains('"+ array.lastname +"')").parent();     // [dddefault^='"+  array.firstname +"']
    //console.log(butSelector.get());
   	
    //console.log($("button").next().get());

   



    if(each==0){
    	console.log("length 2");
		var div = "<div id ='pop-up'>\
		    				<h1><a href='"+array.url+"'</a>" + array.firstname + " " + array.lastname + "</h1>\
		    				<h2>"+ numRatings+"\
		    			</div>";
 			
 					if(overallRating.indexOf("Select")>-1){
    					$("button,#pop-up:visible").after(div);
    					$("#pop-up").append("<div id ='error-message'>This Professor has not yet been rated.")


		   			 }else{
		   			 		
		 					$(butSelector.parent()).after(div); //initializes popup div
		 					
		 					var popupSelector = butSelector.parent().next();
							$(popupSelector).append("<div id ='overallRating'>Overall Rating: " + overallRating);   
						    $(popupSelector).append("<div id ='avgGrade'>Average Grade: " + avgGrade);   
						    $(popupSelector).append("<div id ='helpfulness'>Helpfulness: " + helpfulness);   
						    $(popupSelector).append("<div id ='easiness'>Clarity: " + clarity);  
						    $(popupSelector).append("<div id ='easiness'>Easiness: " + easiness);  
						    $(popupSelector).show();


		   			 }

		    //$("button").after("<div id = 'buffer' </div> ")
		    
    }
    else{


		    var div = "<div id ='pop-up2'>\
		    				<h1><a href='"+array.url+"'</a>" + array.firstname + " " + array.lastname + "</h1>\
		    				<h2>"+ numRatings+"\
		    			</div>";



		    $("#pop-up").after(div);
			$("#pop-up2").append("<div id ='overallRating'>Overall Rating: " + overallRating);   
		    $("#pop-up2").append("<div id ='avgGrade'>Average Grade: " + avgGrade);   
		    $("#pop-up2").append("<div id ='helpfulness'>Helpfulness: " + helpfulness);
		    $("#pop-up2").append("<div id ='easiness'>Clarity: " + clarity);    
		    $("#pop-up2").append("<div id ='easiness'>Easiness: " + easiness);  
	  		$('div#pop-up2:eq(0)').show();
	  }




	  testSelector = $("button td.dddefault:contains('"+ array.lastname +"')");							

	  console.log(testSelector.parent().next().get());

}







profFinder();


